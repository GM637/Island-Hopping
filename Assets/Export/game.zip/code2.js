gdjs.GameCode = {};
gdjs.GameCode.GDForwardObjects2_1final = [];

gdjs.GameCode.GDHungerObjects1_1final = [];

gdjs.GameCode.GDPlayerObjects2_1final = [];

gdjs.GameCode.GDThirstObjects1_1final = [];

gdjs.GameCode.forEachIndex2 = 0;

gdjs.GameCode.forEachIndex3 = 0;

gdjs.GameCode.forEachIndex4 = 0;

gdjs.GameCode.forEachObjects2 = [];

gdjs.GameCode.forEachObjects3 = [];

gdjs.GameCode.forEachObjects4 = [];

gdjs.GameCode.forEachTemporary2 = null;

gdjs.GameCode.forEachTemporary3 = null;

gdjs.GameCode.forEachTemporary4 = null;

gdjs.GameCode.forEachTotalCount2 = 0;

gdjs.GameCode.forEachTotalCount3 = 0;

gdjs.GameCode.forEachTotalCount4 = 0;

gdjs.GameCode.GDTransObjects1= [];
gdjs.GameCode.GDTransObjects2= [];
gdjs.GameCode.GDTransObjects3= [];
gdjs.GameCode.GDTransObjects4= [];
gdjs.GameCode.GDTransObjects5= [];
gdjs.GameCode.GDTransObjects6= [];
gdjs.GameCode.GDTransObjects7= [];
gdjs.GameCode.GDTransObjects8= [];
gdjs.GameCode.GDTransObjects9= [];
gdjs.GameCode.GDTileTempObjects1= [];
gdjs.GameCode.GDTileTempObjects2= [];
gdjs.GameCode.GDTileTempObjects3= [];
gdjs.GameCode.GDTileTempObjects4= [];
gdjs.GameCode.GDTileTempObjects5= [];
gdjs.GameCode.GDTileTempObjects6= [];
gdjs.GameCode.GDTileTempObjects7= [];
gdjs.GameCode.GDTileTempObjects8= [];
gdjs.GameCode.GDTileTempObjects9= [];
gdjs.GameCode.GDPlayerObjects1= [];
gdjs.GameCode.GDPlayerObjects2= [];
gdjs.GameCode.GDPlayerObjects3= [];
gdjs.GameCode.GDPlayerObjects4= [];
gdjs.GameCode.GDPlayerObjects5= [];
gdjs.GameCode.GDPlayerObjects6= [];
gdjs.GameCode.GDPlayerObjects7= [];
gdjs.GameCode.GDPlayerObjects8= [];
gdjs.GameCode.GDPlayerObjects9= [];
gdjs.GameCode.GDPropObjects1= [];
gdjs.GameCode.GDPropObjects2= [];
gdjs.GameCode.GDPropObjects3= [];
gdjs.GameCode.GDPropObjects4= [];
gdjs.GameCode.GDPropObjects5= [];
gdjs.GameCode.GDPropObjects6= [];
gdjs.GameCode.GDPropObjects7= [];
gdjs.GameCode.GDPropObjects8= [];
gdjs.GameCode.GDPropObjects9= [];
gdjs.GameCode.GDShadowPropObjects1= [];
gdjs.GameCode.GDShadowPropObjects2= [];
gdjs.GameCode.GDShadowPropObjects3= [];
gdjs.GameCode.GDShadowPropObjects4= [];
gdjs.GameCode.GDShadowPropObjects5= [];
gdjs.GameCode.GDShadowPropObjects6= [];
gdjs.GameCode.GDShadowPropObjects7= [];
gdjs.GameCode.GDShadowPropObjects8= [];
gdjs.GameCode.GDShadowPropObjects9= [];
gdjs.GameCode.GDItemObjects1= [];
gdjs.GameCode.GDItemObjects2= [];
gdjs.GameCode.GDItemObjects3= [];
gdjs.GameCode.GDItemObjects4= [];
gdjs.GameCode.GDItemObjects5= [];
gdjs.GameCode.GDItemObjects6= [];
gdjs.GameCode.GDItemObjects7= [];
gdjs.GameCode.GDItemObjects8= [];
gdjs.GameCode.GDItemObjects9= [];
gdjs.GameCode.GDTileObjects1= [];
gdjs.GameCode.GDTileObjects2= [];
gdjs.GameCode.GDTileObjects3= [];
gdjs.GameCode.GDTileObjects4= [];
gdjs.GameCode.GDTileObjects5= [];
gdjs.GameCode.GDTileObjects6= [];
gdjs.GameCode.GDTileObjects7= [];
gdjs.GameCode.GDTileObjects8= [];
gdjs.GameCode.GDTileObjects9= [];
gdjs.GameCode.GDDustObjects1= [];
gdjs.GameCode.GDDustObjects2= [];
gdjs.GameCode.GDDustObjects3= [];
gdjs.GameCode.GDDustObjects4= [];
gdjs.GameCode.GDDustObjects5= [];
gdjs.GameCode.GDDustObjects6= [];
gdjs.GameCode.GDDustObjects7= [];
gdjs.GameCode.GDDustObjects8= [];
gdjs.GameCode.GDDustObjects9= [];
gdjs.GameCode.GDHitsObjects1= [];
gdjs.GameCode.GDHitsObjects2= [];
gdjs.GameCode.GDHitsObjects3= [];
gdjs.GameCode.GDHitsObjects4= [];
gdjs.GameCode.GDHitsObjects5= [];
gdjs.GameCode.GDHitsObjects6= [];
gdjs.GameCode.GDHitsObjects7= [];
gdjs.GameCode.GDHitsObjects8= [];
gdjs.GameCode.GDHitsObjects9= [];
gdjs.GameCode.GDSplashObjects1= [];
gdjs.GameCode.GDSplashObjects2= [];
gdjs.GameCode.GDSplashObjects3= [];
gdjs.GameCode.GDSplashObjects4= [];
gdjs.GameCode.GDSplashObjects5= [];
gdjs.GameCode.GDSplashObjects6= [];
gdjs.GameCode.GDSplashObjects7= [];
gdjs.GameCode.GDSplashObjects8= [];
gdjs.GameCode.GDSplashObjects9= [];
gdjs.GameCode.GDEnergyObjects1= [];
gdjs.GameCode.GDEnergyObjects2= [];
gdjs.GameCode.GDEnergyObjects3= [];
gdjs.GameCode.GDEnergyObjects4= [];
gdjs.GameCode.GDEnergyObjects5= [];
gdjs.GameCode.GDEnergyObjects6= [];
gdjs.GameCode.GDEnergyObjects7= [];
gdjs.GameCode.GDEnergyObjects8= [];
gdjs.GameCode.GDEnergyObjects9= [];
gdjs.GameCode.GDThirstObjects1= [];
gdjs.GameCode.GDThirstObjects2= [];
gdjs.GameCode.GDThirstObjects3= [];
gdjs.GameCode.GDThirstObjects4= [];
gdjs.GameCode.GDThirstObjects5= [];
gdjs.GameCode.GDThirstObjects6= [];
gdjs.GameCode.GDThirstObjects7= [];
gdjs.GameCode.GDThirstObjects8= [];
gdjs.GameCode.GDThirstObjects9= [];
gdjs.GameCode.GDHungerObjects1= [];
gdjs.GameCode.GDHungerObjects2= [];
gdjs.GameCode.GDHungerObjects3= [];
gdjs.GameCode.GDHungerObjects4= [];
gdjs.GameCode.GDHungerObjects5= [];
gdjs.GameCode.GDHungerObjects6= [];
gdjs.GameCode.GDHungerObjects7= [];
gdjs.GameCode.GDHungerObjects8= [];
gdjs.GameCode.GDHungerObjects9= [];
gdjs.GameCode.GDDebugObjects1= [];
gdjs.GameCode.GDDebugObjects2= [];
gdjs.GameCode.GDDebugObjects3= [];
gdjs.GameCode.GDDebugObjects4= [];
gdjs.GameCode.GDDebugObjects5= [];
gdjs.GameCode.GDDebugObjects6= [];
gdjs.GameCode.GDDebugObjects7= [];
gdjs.GameCode.GDDebugObjects8= [];
gdjs.GameCode.GDDebugObjects9= [];
gdjs.GameCode.GDDialogueObjects1= [];
gdjs.GameCode.GDDialogueObjects2= [];
gdjs.GameCode.GDDialogueObjects3= [];
gdjs.GameCode.GDDialogueObjects4= [];
gdjs.GameCode.GDDialogueObjects5= [];
gdjs.GameCode.GDDialogueObjects6= [];
gdjs.GameCode.GDDialogueObjects7= [];
gdjs.GameCode.GDDialogueObjects8= [];
gdjs.GameCode.GDDialogueObjects9= [];
gdjs.GameCode.GDDayObjects1= [];
gdjs.GameCode.GDDayObjects2= [];
gdjs.GameCode.GDDayObjects3= [];
gdjs.GameCode.GDDayObjects4= [];
gdjs.GameCode.GDDayObjects5= [];
gdjs.GameCode.GDDayObjects6= [];
gdjs.GameCode.GDDayObjects7= [];
gdjs.GameCode.GDDayObjects8= [];
gdjs.GameCode.GDDayObjects9= [];
gdjs.GameCode.GDJoystickObjects1= [];
gdjs.GameCode.GDJoystickObjects2= [];
gdjs.GameCode.GDJoystickObjects3= [];
gdjs.GameCode.GDJoystickObjects4= [];
gdjs.GameCode.GDJoystickObjects5= [];
gdjs.GameCode.GDJoystickObjects6= [];
gdjs.GameCode.GDJoystickObjects7= [];
gdjs.GameCode.GDJoystickObjects8= [];
gdjs.GameCode.GDJoystickObjects9= [];
gdjs.GameCode.GDRollButtonObjects1= [];
gdjs.GameCode.GDRollButtonObjects2= [];
gdjs.GameCode.GDRollButtonObjects3= [];
gdjs.GameCode.GDRollButtonObjects4= [];
gdjs.GameCode.GDRollButtonObjects5= [];
gdjs.GameCode.GDRollButtonObjects6= [];
gdjs.GameCode.GDRollButtonObjects7= [];
gdjs.GameCode.GDRollButtonObjects8= [];
gdjs.GameCode.GDRollButtonObjects9= [];
gdjs.GameCode.GDActionButtonObjects1= [];
gdjs.GameCode.GDActionButtonObjects2= [];
gdjs.GameCode.GDActionButtonObjects3= [];
gdjs.GameCode.GDActionButtonObjects4= [];
gdjs.GameCode.GDActionButtonObjects5= [];
gdjs.GameCode.GDActionButtonObjects6= [];
gdjs.GameCode.GDActionButtonObjects7= [];
gdjs.GameCode.GDActionButtonObjects8= [];
gdjs.GameCode.GDActionButtonObjects9= [];
gdjs.GameCode.GDTestTerrainObjects1= [];
gdjs.GameCode.GDTestTerrainObjects2= [];
gdjs.GameCode.GDTestTerrainObjects3= [];
gdjs.GameCode.GDTestTerrainObjects4= [];
gdjs.GameCode.GDTestTerrainObjects5= [];
gdjs.GameCode.GDTestTerrainObjects6= [];
gdjs.GameCode.GDTestTerrainObjects7= [];
gdjs.GameCode.GDTestTerrainObjects8= [];
gdjs.GameCode.GDTestTerrainObjects9= [];
gdjs.GameCode.GDTilesObjects1= [];
gdjs.GameCode.GDTilesObjects2= [];
gdjs.GameCode.GDTilesObjects3= [];
gdjs.GameCode.GDTilesObjects4= [];
gdjs.GameCode.GDTilesObjects5= [];
gdjs.GameCode.GDTilesObjects6= [];
gdjs.GameCode.GDTilesObjects7= [];
gdjs.GameCode.GDTilesObjects8= [];
gdjs.GameCode.GDTilesObjects9= [];
gdjs.GameCode.GDUITextObjects1= [];
gdjs.GameCode.GDUITextObjects2= [];
gdjs.GameCode.GDUITextObjects3= [];
gdjs.GameCode.GDUITextObjects4= [];
gdjs.GameCode.GDUITextObjects5= [];
gdjs.GameCode.GDUITextObjects6= [];
gdjs.GameCode.GDUITextObjects7= [];
gdjs.GameCode.GDUITextObjects8= [];
gdjs.GameCode.GDUITextObjects9= [];
gdjs.GameCode.GDUIText2Objects1= [];
gdjs.GameCode.GDUIText2Objects2= [];
gdjs.GameCode.GDUIText2Objects3= [];
gdjs.GameCode.GDUIText2Objects4= [];
gdjs.GameCode.GDUIText2Objects5= [];
gdjs.GameCode.GDUIText2Objects6= [];
gdjs.GameCode.GDUIText2Objects7= [];
gdjs.GameCode.GDUIText2Objects8= [];
gdjs.GameCode.GDUIText2Objects9= [];
gdjs.GameCode.GDUIText3Objects1= [];
gdjs.GameCode.GDUIText3Objects2= [];
gdjs.GameCode.GDUIText3Objects3= [];
gdjs.GameCode.GDUIText3Objects4= [];
gdjs.GameCode.GDUIText3Objects5= [];
gdjs.GameCode.GDUIText3Objects6= [];
gdjs.GameCode.GDUIText3Objects7= [];
gdjs.GameCode.GDUIText3Objects8= [];
gdjs.GameCode.GDUIText3Objects9= [];
gdjs.GameCode.GDFogObjects1= [];
gdjs.GameCode.GDFogObjects2= [];
gdjs.GameCode.GDFogObjects3= [];
gdjs.GameCode.GDFogObjects4= [];
gdjs.GameCode.GDFogObjects5= [];
gdjs.GameCode.GDFogObjects6= [];
gdjs.GameCode.GDFogObjects7= [];
gdjs.GameCode.GDFogObjects8= [];
gdjs.GameCode.GDFogObjects9= [];
gdjs.GameCode.GDInventIconObjects1= [];
gdjs.GameCode.GDInventIconObjects2= [];
gdjs.GameCode.GDInventIconObjects3= [];
gdjs.GameCode.GDInventIconObjects4= [];
gdjs.GameCode.GDInventIconObjects5= [];
gdjs.GameCode.GDInventIconObjects6= [];
gdjs.GameCode.GDInventIconObjects7= [];
gdjs.GameCode.GDInventIconObjects8= [];
gdjs.GameCode.GDInventIconObjects9= [];
gdjs.GameCode.GDClockObjects1= [];
gdjs.GameCode.GDClockObjects2= [];
gdjs.GameCode.GDClockObjects3= [];
gdjs.GameCode.GDClockObjects4= [];
gdjs.GameCode.GDClockObjects5= [];
gdjs.GameCode.GDClockObjects6= [];
gdjs.GameCode.GDClockObjects7= [];
gdjs.GameCode.GDClockObjects8= [];
gdjs.GameCode.GDClockObjects9= [];
gdjs.GameCode.GDForwardObjects1= [];
gdjs.GameCode.GDForwardObjects2= [];
gdjs.GameCode.GDForwardObjects3= [];
gdjs.GameCode.GDForwardObjects4= [];
gdjs.GameCode.GDForwardObjects5= [];
gdjs.GameCode.GDForwardObjects6= [];
gdjs.GameCode.GDForwardObjects7= [];
gdjs.GameCode.GDForwardObjects8= [];
gdjs.GameCode.GDForwardObjects9= [];
gdjs.GameCode.GDCampObjects1= [];
gdjs.GameCode.GDCampObjects2= [];
gdjs.GameCode.GDCampObjects3= [];
gdjs.GameCode.GDCampObjects4= [];
gdjs.GameCode.GDCampObjects5= [];
gdjs.GameCode.GDCampObjects6= [];
gdjs.GameCode.GDCampObjects7= [];
gdjs.GameCode.GDCampObjects8= [];
gdjs.GameCode.GDCampObjects9= [];
gdjs.GameCode.GDSundialObjects1= [];
gdjs.GameCode.GDSundialObjects2= [];
gdjs.GameCode.GDSundialObjects3= [];
gdjs.GameCode.GDSundialObjects4= [];
gdjs.GameCode.GDSundialObjects5= [];
gdjs.GameCode.GDSundialObjects6= [];
gdjs.GameCode.GDSundialObjects7= [];
gdjs.GameCode.GDSundialObjects8= [];
gdjs.GameCode.GDSundialObjects9= [];


gdjs.GameCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CHECK")) == 0;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day").add(1);
}{gdjs.evtTools.storage.writeStringInJSONFile("Player", "Data", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Main", "Check", 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("CHECK")) == 1;
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("Player", "Data", runtimeScene, runtimeScene.getScene().getVariables().get("READ"));
}{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("READ")), runtimeScene.getGame().getVariables().getFromIndex(0));
}}

}


};gdjs.GameCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDTestTerrainObjects1, gdjs.GameCode.GDTestTerrainObjects4);

{for(var i = 0, len = gdjs.GameCode.GDTestTerrainObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDTestTerrainObjects4[i].setFillOpacity(500 * gdjs.evtsExt__Noise__Noise2d.func(runtimeScene, "Island", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("PerlinZoom")), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("PerlinZoom")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDTestTerrainObjects1, gdjs.GameCode.GDTestTerrainObjects4);

{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(gdjs.evtTools.common.distanceBetweenPositions(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) / 2, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) / 2));
}{for(var i = 0, len = gdjs.GameCode.GDTestTerrainObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDTestTerrainObjects4[i].setFillOpacity(gdjs.GameCode.GDTestTerrainObjects4[i].getFillOpacity() * (1 - Math.min(1, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5)) / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(6)))));
}
}{for(var i = 0, len = gdjs.GameCode.GDTestTerrainObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDTestTerrainObjects4[i].setFillColor(gdjs.evtsExt__ColorConversion__RgbMean.func(runtimeScene, "28;126;158", "30;168;57", (gdjs.GameCode.GDTestTerrainObjects4[i].getFillOpacity()) / 160, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDTestTerrainObjects1, gdjs.GameCode.GDTestTerrainObjects4);

{gdjs.evtTools.variable.valuePush(runtimeScene.getScene().getVariables().getFromIndex(9), Math.floor((( gdjs.GameCode.GDTestTerrainObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDTestTerrainObjects4[0].getFillOpacity()) / 255 * 8));
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDTestTerrainObjects1, gdjs.GameCode.GDTestTerrainObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTestTerrainObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDTestTerrainObjects4[i].getFillOpacity() > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("HighPoint")) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTestTerrainObjects4[k] = gdjs.GameCode.GDTestTerrainObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDTestTerrainObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Camp"), gdjs.GameCode.GDCampObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects4);
/* Reuse gdjs.GameCode.GDTestTerrainObjects4 */
{runtimeScene.getScene().getVariables().get("HighPoint").setNumber((( gdjs.GameCode.GDTestTerrainObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDTestTerrainObjects4[0].getFillOpacity()));
}{runtimeScene.getScene().getVariables().get("HighPointID").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)));
}{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects4[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) * 16,gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) * 16);
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 500, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.GameCode.GDPlayerObjects4.length !== 0 ? gdjs.GameCode.GDPlayerObjects4[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.GameCode.GDCampObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDCampObjects4[i].putAroundObject((gdjs.GameCode.GDPlayerObjects4.length !== 0 ? gdjs.GameCode.GDPlayerObjects4[0] : null), 0, 0);
}
}{for(var i = 0, len = gdjs.GameCode.GDCampObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDCampObjects4[i].setZOrder(3);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDTestTerrainObjects1, gdjs.GameCode.GDTestTerrainObjects4);

{for(var i = 0, len = gdjs.GameCode.GDTestTerrainObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDTestTerrainObjects4[i].setFillOpacity(255);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects2Objects = Hashtable.newFrom({"Prop": gdjs.GameCode.GDPropObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDShadowPropObjects1Objects = Hashtable.newFrom({"ShadowProp": gdjs.GameCode.GDShadowPropObjects1});
gdjs.GameCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.readNumberFromJSONFile("Main", "Check", runtimeScene, runtimeScene.getScene().getVariables().get("CHECK"));
}
{ //Subevents
gdjs.GameCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) < 4;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("Biome").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")));
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Thirst"), gdjs.GameCode.GDThirstObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0).setNumber(Math.max(0, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) * gdjs.randomInRange(2, 3)));
}{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1).setNumber(Math.max(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) - 2) * gdjs.randomInRange(2, 3)));
}{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2).setNumber(Math.max(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) - 3) * gdjs.randomInRange(2, 3)));
}{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3).setNumber(Math.max(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) - 4) * gdjs.randomInRange(2, 3)));
}{for(var i = 0, len = gdjs.GameCode.GDHungerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects2[i].SetValue(100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDThirstObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDThirstObjects2[i].SetValue(100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


const repeatCount3 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3));
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3));
if (isConditionTrue_0)
{

{ //Subevents: 
gdjs.GameCode.eventsList1(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Prop"), gdjs.GameCode.GDPropObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects2Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPropObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDPropObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPropObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ShadowProp"), gdjs.GameCode.GDShadowPropObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDShadowPropObjects1Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDShadowPropObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDShadowPropObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDShadowPropObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtsExt__Noise__Create.func(runtimeScene, "Island", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(80);
}{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(4);
}{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(40);
}{runtimeScene.getScene().getVariables().get("PerlinZoom").setNumber(gdjs.randomFloatInRange(0.055, 0.005));
}{runtimeScene.getScene().getVariables().get("TIME").setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TestTerrain"), gdjs.GameCode.GDTestTerrainObjects1);
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().getFromIndex(9));
}{runtimeScene.getScene().getVariables().get("HighPoint").setNumber(0);
}{runtimeScene.getScene().getVariables().get("HighPointID").setNumber(0);
}{for(var i = 0, len = gdjs.GameCode.GDTestTerrainObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDTestTerrainObjects1[i].clear();
}
}{runtimeScene.getScene().getVariables().get("Biome").setNumber(gdjs.randomInRange(0, 4));
}{runtimeScene.getScene().getVariables().get("PerlinZoom").setNumber(gdjs.randomFloatInRange(0.055, 0.005));
}{runtimeScene.getScene().getVariables().get("TIME").setNumber(0);
}
{ //Subevents
gdjs.GameCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("Biome").setNumber(gdjs.randomInRange(0, 3));
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 15, "", 0);
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\theo-aabel-constellation-128-ytshorts.savetube.me.mp3", 2, true, 25, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Map"));
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects2Objects = Hashtable.newFrom({"Tile": gdjs.GameCode.GDTileObjects2});
gdjs.GameCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.GameCode.GDTileObjects2);
{gdjs.evtsExt__CreateMultipleCopiesOfObject__CreateMultipleCopiesOfObject.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects2Objects, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TerrainSize")), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TerrainSize")), 0, 0, 0, 0, "Tile", "", 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.GameCode.GDTileObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTileObjects2[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Biome")));
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects2Objects = Hashtable.newFrom({"Tile": gdjs.GameCode.GDTileObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects4Objects = Hashtable.newFrom({"Tile": gdjs.GameCode.GDTileObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects4Objects = Hashtable.newFrom({"Prop": gdjs.GameCode.GDPropObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects4Objects = Hashtable.newFrom({"Tile": gdjs.GameCode.GDTileObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects4Objects = Hashtable.newFrom({"Prop": gdjs.GameCode.GDPropObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects4Objects = Hashtable.newFrom({"Prop": gdjs.GameCode.GDPropObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDShadowPropObjects4Objects = Hashtable.newFrom({"ShadowProp": gdjs.GameCode.GDShadowPropObjects4});
gdjs.GameCode.eventsList6 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDPropObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects4[i].getAnimation() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects4[k] = gdjs.GameCode.GDPropObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPropObjects4 */
/* Reuse gdjs.GameCode.GDTileObjects4 */
{for(var i = 0, len = gdjs.GameCode.GDPropObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDPropObjects4[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GameCode.GDPropObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDPropObjects4[i].setAnimationFrame(Math.floor((( gdjs.GameCode.GDTileObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects4[0].getAnimationFrame()) / 2));
}
}}

}


};gdjs.GameCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Tile")))) <= 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDTileObjects4, gdjs.GameCode.GDTileObjects5);

{for(var i = 0, len = gdjs.GameCode.GDTileObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDTileObjects5[i].setAnimationFrame(0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Tile")))) > 7);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDTileObjects4, gdjs.GameCode.GDTileObjects5);

{for(var i = 0, len = gdjs.GameCode.GDTileObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDTileObjects5[i].setAnimationFrame(7);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Prop"), gdjs.GameCode.GDPropObjects4);
/* Reuse gdjs.GameCode.GDTileObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.common.mod((( gdjs.GameCode.GDTileObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects4[0].getPointX("")) * 9 + (( gdjs.GameCode.GDTileObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects4[0].getPointY("")) * 4 - 95, (( gdjs.GameCode.GDTileObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects4[0].getPointX("")) / 16) <= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Biome")) * 0.745);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects4Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects4Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects4[i].getX() > 96 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects4[k] = gdjs.GameCode.GDTileObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects4[i].getY() > 96 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects4[k] = gdjs.GameCode.GDTileObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects4[i].getX() < 1280 - 128 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects4[k] = gdjs.GameCode.GDTileObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects4[i].getY() < 1280 - 128 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects4[k] = gdjs.GameCode.GDTileObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects4Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects4Objects, 48, true);
}
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDTileObjects4 */
/* Reuse gdjs.GameCode.GDPropObjects4 */
gdjs.GameCode.GDShadowPropObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects4Objects, (( gdjs.GameCode.GDTileObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects4[0].getCenterXInScene()), (( gdjs.GameCode.GDTileObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects4[0].getCenterYInScene()), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDShadowPropObjects4Objects, (( gdjs.GameCode.GDTileObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects4[0].getCenterXInScene()), (( gdjs.GameCode.GDTileObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects4[0].getCenterYInScene()), "");
}
{ //Subevents
gdjs.GameCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDTileObjects3, gdjs.GameCode.GDTileObjects4);

{for(var i = 0, len = gdjs.GameCode.GDTileObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDTileObjects4[i].setAnimationFrame(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Tile")))));
}
}
{ //Subevents
gdjs.GameCode.eventsList7(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDTileObjects2 */

for (gdjs.GameCode.forEachIndex3 = 0;gdjs.GameCode.forEachIndex3 < gdjs.GameCode.GDTileObjects2.length;++gdjs.GameCode.forEachIndex3) {
gdjs.GameCode.GDTileObjects3.length = 0;


gdjs.GameCode.forEachTemporary3 = gdjs.GameCode.GDTileObjects2[gdjs.GameCode.forEachIndex3];
gdjs.GameCode.GDTileObjects3.push(gdjs.GameCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getScene().getVariables().get("Tile").setNumber(gdjs.evtTools.common.mod((( gdjs.GameCode.GDTileObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects3[0].getPointX("")) / 16, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))) + Math.round(((( gdjs.GameCode.GDTileObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects3[0].getPointY("")) / 16) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3))));
}
{ //Subevents: 
gdjs.GameCode.eventsList8(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDShadowPropObjects3Objects = Hashtable.newFrom({"ShadowProp": gdjs.GameCode.GDShadowPropObjects3});
gdjs.GameCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDPropObjects2, gdjs.GameCode.GDPropObjects3);

gdjs.copyArray(runtimeScene.getObjects("ShadowProp"), gdjs.GameCode.GDShadowPropObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickNearestObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDShadowPropObjects3Objects, (( gdjs.GameCode.GDPropObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects3[0].getPointX("")), (( gdjs.GameCode.GDPropObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects3[0].getPointY("")), false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPropObjects3 */
/* Reuse gdjs.GameCode.GDShadowPropObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDShadowPropObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDShadowPropObjects3[i].putAroundObject((gdjs.GameCode.GDPropObjects3.length !== 0 ? gdjs.GameCode.GDPropObjects3[0] : null), 0, 0);
}
}{for(var i = 0, len = gdjs.GameCode.GDShadowPropObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDShadowPropObjects3[i].setAnimationFrame((( gdjs.GameCode.GDPropObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects3[0].getAnimationFrame()));
}
}{for(var i = 0, len = gdjs.GameCode.GDShadowPropObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDShadowPropObjects3[i].setAngle((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) + 1) * 90 + 35 + (( gdjs.GameCode.GDPropObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.GameCode.GDShadowPropObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDShadowPropObjects3[i].setZOrder((( gdjs.GameCode.GDPropObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects3[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.GameCode.GDShadowPropObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDShadowPropObjects3[i].setColor("0;0;0");
}
}{for(var i = 0, len = gdjs.GameCode.GDShadowPropObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDShadowPropObjects3[i].setOpacity(Math.min((( gdjs.GameCode.GDPropObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects3[0].getOpacity()), 1) * 75);
}
}{for(var i = 0, len = gdjs.GameCode.GDShadowPropObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDShadowPropObjects3[i].hide(false);
}
}}

}


};gdjs.GameCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("TerrainRenDist").setNumber(8);
}{runtimeScene.getScene().getVariables().get("TerrainSize").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TerrainRenDist")) * 2);
}{runtimeScene.getScene().getVariables().get("TerrainID").setNumber(0);
}
{ //Subevents
gdjs.GameCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.GameCode.GDPlayerObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameCode.GDPlayerObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);
{isConditionTrue_1 = (Math.round((( gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects3[0].getPointX("")) / 32) * 32 != (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameCode.GDPlayerObjects3[0].getVariables()).get("LastX"))));
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDPlayerObjects2_1final.indexOf(gdjs.GameCode.GDPlayerObjects3[j]) === -1 )
            gdjs.GameCode.GDPlayerObjects2_1final.push(gdjs.GameCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);
{isConditionTrue_1 = (Math.round((( gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects3[0].getPointY("")) / 32) * 32 != (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameCode.GDPlayerObjects3[0].getVariables()).get("LastY"))));
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDPlayerObjects3.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDPlayerObjects2_1final.indexOf(gdjs.GameCode.GDPlayerObjects3[j]) === -1 )
            gdjs.GameCode.GDPlayerObjects2_1final.push(gdjs.GameCode.GDPlayerObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameCode.GDPlayerObjects2_1final, gdjs.GameCode.GDPlayerObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.GameCode.GDTileObjects2);
{for(var i = 0, len = gdjs.GameCode.GDTileObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTileObjects2[i].setCenterPositionInScene(((gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDTileObjects2[i].getVariables().get("RowID"))) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TerrainRenDist"))) * 16 + (( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointX("")) - 8,((gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDTileObjects2[i].getVariables().get("ColumnID"))) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TerrainRenDist"))) * 16 + (( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointY("")) - 8);
}
}{gdjs.evtsExt__SnapToGrid__SnapObjectToVirtualGrid.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects2Objects, 16, 16, 0, 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].returnVariable(gdjs.GameCode.GDPlayerObjects2[i].getVariables().get("LastX")).setNumber(Math.round((gdjs.GameCode.GDPlayerObjects2[i].getPointX("")) / 32) * 32);
}
}{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].returnVariable(gdjs.GameCode.GDPlayerObjects2[i].getVariables().get("LastY")).setNumber(Math.round((gdjs.GameCode.GDPlayerObjects2[i].getPointY("")) / 32) * 32);
}
}{for(var i = 0, len = gdjs.GameCode.GDTileObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTileObjects2[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Biome")));
}
}
{ //Subevents
gdjs.GameCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.GameCode.GDTileObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects2[i].getAnimationFrame() != 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects2[k] = gdjs.GameCode.GDTileObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDTileObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDTileObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTileObjects2[i].setOpacity(255);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.GameCode.GDTileObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects2[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects2[k] = gdjs.GameCode.GDTileObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDTileObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDTileObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTileObjects2[i].setOpacity(125 + Math.sin(gdjs.evtTools.runtimeScene.getTimeFromStartInSeconds(runtimeScene)) * 45);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Prop"), gdjs.GameCode.GDPropObjects1);

for (gdjs.GameCode.forEachIndex2 = 0;gdjs.GameCode.forEachIndex2 < gdjs.GameCode.GDPropObjects1.length;++gdjs.GameCode.forEachIndex2) {
gdjs.GameCode.GDPropObjects2.length = 0;


gdjs.GameCode.forEachTemporary2 = gdjs.GameCode.GDPropObjects1[gdjs.GameCode.forEachIndex2];
gdjs.GameCode.GDPropObjects2.push(gdjs.GameCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.GameCode.eventsList10(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameCode.eventsList12 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDPlayerObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDPlayerObjects3[i].isCurrentAnimationName("Dash")) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects3[k] = gdjs.GameCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].setAnimationName("Run");
}
}{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").setMaxSpeed(80);
}
}}

}


};gdjs.GameCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDPlayerObjects2, gdjs.GameCode.GDPlayerObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects4.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDPlayerObjects4[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects4[k] = gdjs.GameCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects4.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDPlayerObjects4[i].isCurrentAnimationName("Dash")) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects4[k] = gdjs.GameCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dust"), gdjs.GameCode.GDDustObjects4);
/* Reuse gdjs.GameCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects4[i].setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.GameCode.GDDustObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDustObjects4[i].stopEmission();
}
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDPlayerObjects2, gdjs.GameCode.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects3[k] = gdjs.GameCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dust"), gdjs.GameCode.GDDustObjects3);
{for(var i = 0, len = gdjs.GameCode.GDDustObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDustObjects3[i].startEmission();
}
}
{ //Subevents
gdjs.GameCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList14 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDTileObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects3[i].getAnimationFrame() < 1 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects3[k] = gdjs.GameCode.GDTileObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects3);
/* Reuse gdjs.GameCode.GDPlayerObjects3 */
/* Reuse gdjs.GameCode.GDThirstObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").setMaxSpeed(20);
}
}{for(var i = 0, len = gdjs.GameCode.GDHungerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects3[i].SetValue(gdjs.GameCode.GDHungerObjects3[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (0.2), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDThirstObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDThirstObjects3[i].SetValue(gdjs.GameCode.GDThirstObjects3[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (-(0.1)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.GameCode.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDPlayerObjects2, gdjs.GameCode.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects3.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDPlayerObjects3[i].isCurrentAnimationName("Dash")) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects3[k] = gdjs.GameCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].setAnimationName("Swim");
}
}{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").setMaxSpeed(40);
}
}
{ //Subevents
gdjs.GameCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList16 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDTileObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects3[i].getAnimationFrame() > 6 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects3[k] = gdjs.GameCode.GDTileObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").setMaxSpeed(25);
}
}}

}


};gdjs.GameCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDPlayerObjects2, gdjs.GameCode.GDPlayerObjects3);

gdjs.copyArray(gdjs.GameCode.GDTileObjects2, gdjs.GameCode.GDTileObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects3[i].getAnimationFrame() > 5 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects3[k] = gdjs.GameCode.GDTileObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects3[k] = gdjs.GameCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects3);
/* Reuse gdjs.GameCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").setMaxSpeed(40);
}
}{for(var i = 0, len = gdjs.GameCode.GDHungerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects3[i].SetValue(gdjs.GameCode.GDHungerObjects3[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (0.025), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList16(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDTileObjects2, gdjs.GameCode.GDTileObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects3.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDTileObjects3[i].getAnimationFrame() < 2) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects3[k] = gdjs.GameCode.GDTileObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Splash"), gdjs.GameCode.GDSplashObjects3);
{for(var i = 0, len = gdjs.GameCode.GDSplashObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSplashObjects3[i].stopEmission();
}
}
{ //Subevents
gdjs.GameCode.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameCode.GDTileObjects2, gdjs.GameCode.GDTileObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects3[i].getAnimationFrame() < 2 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects3[k] = gdjs.GameCode.GDTileObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Splash"), gdjs.GameCode.GDSplashObjects3);
gdjs.copyArray(runtimeScene.getObjects("Thirst"), gdjs.GameCode.GDThirstObjects3);
{for(var i = 0, len = gdjs.GameCode.GDSplashObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDSplashObjects3[i].startEmission();
}
}{for(var i = 0, len = gdjs.GameCode.GDThirstObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDThirstObjects3[i].SetValue(gdjs.GameCode.GDThirstObjects3[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (-(0.1)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList15(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Biome")) == 2;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.GameCode.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Biome")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects2[k] = gdjs.GameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects2.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Thirst"), gdjs.GameCode.GDThirstObjects2);
{for(var i = 0, len = gdjs.GameCode.GDThirstObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDThirstObjects2[i].SetValue(gdjs.GameCode.GDThirstObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (0.05), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.GameCode.eventsList19 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(gdjs.GameCode.GDTileObjects3, gdjs.GameCode.GDTileObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects4[i].getAnimationFrame() < 2 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects4[k] = gdjs.GameCode.GDTileObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects4);
{for(var i = 0, len = gdjs.GameCode.GDHungerObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects4[i].SetValue(gdjs.GameCode.GDHungerObjects4[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (5), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

/* Reuse gdjs.GameCode.GDTileObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects3.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDTileObjects3[i].getAnimationFrame() < 2) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects3[k] = gdjs.GameCode.GDTileObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Thirst"), gdjs.GameCode.GDThirstObjects3);
{for(var i = 0, len = gdjs.GameCode.GDThirstObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDThirstObjects3[i].SetValue(gdjs.GameCode.GDThirstObjects3[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (5), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.GameCode.eventsList20 = function(runtimeScene, asyncObjectsList) {

{

/* Reuse gdjs.GameCode.GDPlayerObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.GameCode.GDTileObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects3[i].isCollidingWithPoint((( gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects3[0].getPointY(""))) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects3[k] = gdjs.GameCode.GDTileObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList19(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16171204 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].getBehavior("TopDownMovement").setMaxSpeed(60);
}
}{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].setAnimationName("Idle");
}
}
{ //Subevents
gdjs.GameCode.eventsList20(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3), (runtimeScene) => (gdjs.GameCode.asyncCallback16171204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCampObjects1Objects = Hashtable.newFrom({"Camp": gdjs.GameCode.GDCampObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects2Objects = Hashtable.newFrom({"Item": gdjs.GameCode.GDItemObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects3Objects = Hashtable.newFrom({"Item": gdjs.GameCode.GDItemObjects3});
gdjs.GameCode.asyncCallback16177252 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Camp"), gdjs.GameCode.GDCampObjects3);

gdjs.GameCode.GDItemObjects3.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(1).sub(1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1).sub(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects3Objects, (( gdjs.GameCode.GDCampObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDCampObjects3[0].getPointX("Deposit")) - 8, (( gdjs.GameCode.GDCampObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDCampObjects3[0].getPointY("Deposit")), "");
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].returnVariable(gdjs.GameCode.GDItemObjects3[i].getVariables().getFromIndex(0)).setNumber(3);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].returnVariable(gdjs.GameCode.GDItemObjects3[i].getVariables().get("Y")).setNumber((gdjs.GameCode.GDItemObjects3[i].getY()) + 16);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].returnVariable(gdjs.GameCode.GDItemObjects3[i].getVariables().get("F")).setNumber(15);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Item", false, 25, gdjs.randomFloatInRange(0.9, 1.1));
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].setXOffset(16);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].setYOffset(16);
}
}}
gdjs.GameCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameCode.GDCampObjects1) asyncObjectsList.addObject("Camp", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3 / 4), (runtimeScene) => (gdjs.GameCode.asyncCallback16177252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects3Objects = Hashtable.newFrom({"Item": gdjs.GameCode.GDItemObjects3});
gdjs.GameCode.asyncCallback16180908 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Camp"), gdjs.GameCode.GDCampObjects3);

gdjs.GameCode.GDItemObjects3.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(2).sub(1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2).sub(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects3Objects, (( gdjs.GameCode.GDCampObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDCampObjects3[0].getPointX("Deposit")) - 8, (( gdjs.GameCode.GDCampObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDCampObjects3[0].getPointY("Deposit")), "");
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].returnVariable(gdjs.GameCode.GDItemObjects3[i].getVariables().getFromIndex(0)).setNumber(3);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].returnVariable(gdjs.GameCode.GDItemObjects3[i].getVariables().get("Y")).setNumber((gdjs.GameCode.GDItemObjects3[i].getY()) + 16);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].returnVariable(gdjs.GameCode.GDItemObjects3[i].getVariables().get("F")).setNumber(15);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Item", false, 25, gdjs.randomFloatInRange(0.9, 1.1));
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].setXOffset(32);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].setYOffset(16);
}
}}
gdjs.GameCode.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameCode.GDCampObjects1) asyncObjectsList.addObject("Camp", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3 / 4 * 2), (runtimeScene) => (gdjs.GameCode.asyncCallback16180908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects3Objects = Hashtable.newFrom({"Item": gdjs.GameCode.GDItemObjects3});
gdjs.GameCode.asyncCallback16184140 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Camp"), gdjs.GameCode.GDCampObjects3);

gdjs.GameCode.GDItemObjects3.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(3).sub(1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3).sub(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects3Objects, (( gdjs.GameCode.GDCampObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDCampObjects3[0].getPointX("Deposit")) - 8, (( gdjs.GameCode.GDCampObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDCampObjects3[0].getPointY("Deposit")), "");
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].returnVariable(gdjs.GameCode.GDItemObjects3[i].getVariables().getFromIndex(0)).setNumber(3);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].returnVariable(gdjs.GameCode.GDItemObjects3[i].getVariables().get("Y")).setNumber((gdjs.GameCode.GDItemObjects3[i].getY()) + 16);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].returnVariable(gdjs.GameCode.GDItemObjects3[i].getVariables().get("F")).setNumber(15);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Item", false, 25, gdjs.randomFloatInRange(0.9, 1.1));
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].setXOffset(48);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects3[i].setYOffset(16);
}
}}
gdjs.GameCode.eventsList24 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameCode.GDCampObjects1) asyncObjectsList.addObject("Camp", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.3 / 4 * 3), (runtimeScene) => (gdjs.GameCode.asyncCallback16184140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.asyncCallback16190852 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects5);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].hide();
}
}}
gdjs.GameCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects4) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.GameCode.asyncCallback16190852(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDDialogueObjects3, gdjs.GameCode.GDDialogueObjects4);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].setString("Or FAST FOWARD\nif I want to....");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.GameCode.asyncCallback16189700 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide();
}
}
{ //Subevents
gdjs.GameCode.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects2) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.GameCode.asyncCallback16189700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList28 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDDialogueObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].setString("I could look around\n.....");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList27(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16188548 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects2);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].hide();
}
}
{ //Subevents
gdjs.GameCode.eventsList28(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList29 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameCode.GDDialogueObjects1) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.GameCode.asyncCallback16188548(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList30 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects1);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects1[i].setString("Nice. \nThat should be it\nfor today...");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects1[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList29(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList31 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "1", 0.3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(0)) > 0;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDCampObjects1, gdjs.GameCode.GDCampObjects2);

gdjs.GameCode.GDItemObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(0).sub(1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0).sub(1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects2Objects, (( gdjs.GameCode.GDCampObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDCampObjects2[0].getPointX("Deposit")) - 8, (( gdjs.GameCode.GDCampObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDCampObjects2[0].getPointY("Deposit")), "");
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects2[i].returnVariable(gdjs.GameCode.GDItemObjects2[i].getVariables().getFromIndex(0)).setNumber(3);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects2[i].returnVariable(gdjs.GameCode.GDItemObjects2[i].getVariables().get("Y")).setNumber((gdjs.GameCode.GDItemObjects2[i].getY()) + 16);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects2[i].returnVariable(gdjs.GameCode.GDItemObjects2[i].getVariables().get("F")).setNumber(15);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Item", false, 25, gdjs.randomFloatInRange(0.9, 1.1));
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects2[i].setXOffset(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects2[i].setYOffset(16);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "2", 0.3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(1)) > 0;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList22(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "3", 0.3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(2)) > 0;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList23(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__RepeatEveryXSeconds__Repeat.func(runtimeScene, "4", 0.3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3)) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(3)) > 0;
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList24(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16187468);
}
}
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList30(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList32 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.GameCode.GDJoystickObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDJoystickObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDJoystickObjects2[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDJoystickObjects2[k] = gdjs.GameCode.GDJoystickObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDJoystickObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDJoystickObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").simulateStick((( gdjs.GameCode.GDJoystickObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDJoystickObjects2[0].StickAngle((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (( gdjs.GameCode.GDJoystickObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDJoystickObjects2[0].StickForce((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dust"), gdjs.GameCode.GDDustObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Splash"), gdjs.GameCode.GDSplashObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDustObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDustObjects2[i].putAroundObject((gdjs.GameCode.GDPlayerObjects2.length !== 0 ? gdjs.GameCode.GDPlayerObjects2[0] : null), 0, 0);
}
}{for(var i = 0, len = gdjs.GameCode.GDSplashObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSplashObjects2[i].putAroundObject((gdjs.GameCode.GDPlayerObjects2.length !== 0 ? gdjs.GameCode.GDPlayerObjects2[0] : null), 0, 0);
}
}{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].getBehavior("SmoothCamera").SetOffsetYOp(-(10), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").getXVelocity() < 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects2[k] = gdjs.GameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].getBehavior("ThreeDFlip").FlipTo(true, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").getXVelocity() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects2[k] = gdjs.GameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].getBehavior("ThreeDFlip").FlipTo(false, 150, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.GameCode.GDTileObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects2[i].isCollidingWithPoint((( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointX("")), (( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointY(""))) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects2[k] = gdjs.GameCode.GDTileObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Energy"), gdjs.GameCode.GDEnergyObjects2);
gdjs.copyArray(runtimeScene.getObjects("RollButton"), gdjs.GameCode.GDRollButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDEnergyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDEnergyObjects2[i].IsFull((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDEnergyObjects2[k] = gdjs.GameCode.GDEnergyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDEnergyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDRollButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDRollButtonObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDRollButtonObjects2[k] = gdjs.GameCode.GDRollButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDRollButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16169836);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dust"), gdjs.GameCode.GDDustObjects2);
/* Reuse gdjs.GameCode.GDEnergyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").setMaxSpeed(1000);
}
}{for(var i = 0, len = gdjs.GameCode.GDDustObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDustObjects2[i].setFlow(500);
}
}{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].setAnimationName("Dash");
}
}{for(var i = 0, len = gdjs.GameCode.GDDustObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDustObjects2[i].setFlow(5);
}
}{for(var i = 0, len = gdjs.GameCode.GDEnergyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnergyObjects2[i].SetValue(0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList21(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Camp"), gdjs.GameCode.GDCampObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCampObjects1Objects, 56, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) > 0.3;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects1[i].getBehavior("SmoothCamera").SetOffsetYOp(-(20), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList31(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects2Objects = Hashtable.newFrom({"Prop": gdjs.GameCode.GDPropObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHitsObjects2Objects = Hashtable.newFrom({"Hits": gdjs.GameCode.GDHitsObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHitsObjects4Objects = Hashtable.newFrom({"Hits": gdjs.GameCode.GDHitsObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects6Objects = Hashtable.newFrom({"Item": gdjs.GameCode.GDItemObjects6});
gdjs.GameCode.eventsList33 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.random(10) < 4);
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDItemObjects7 */
{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setXOffset(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setYOffset(16);
}
}}

}


};gdjs.GameCode.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.random(10) < 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDItemObjects7, gdjs.GameCode.GDItemObjects8);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects8.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects8[i].setXOffset(48);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects8.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects8[i].setYOffset(16);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.random(10) < 1);
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDItemObjects7 */
{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setXOffset(32);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setYOffset(16);
}
}}

}


};gdjs.GameCode.eventsList35 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(gdjs.GameCode.GDPropObjects6, gdjs.GameCode.GDPropObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects7.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects7[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects7[k] = gdjs.GameCode.GDPropObjects7[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects7.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDItemObjects6, gdjs.GameCode.GDItemObjects7);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setXOffset(gdjs.randomInRange(0, 3) * 16);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setYOffset(gdjs.randomInRange(0, 1) * 16);
}
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDPropObjects6, gdjs.GameCode.GDPropObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects7.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects7[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects7[k] = gdjs.GameCode.GDPropObjects7[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects7.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects7);
gdjs.copyArray(gdjs.GameCode.GDItemObjects6, gdjs.GameCode.GDItemObjects7);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setXOffset(32);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setYOffset(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDHungerObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects7[i].SetValue(gdjs.GameCode.GDHungerObjects7[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList33(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameCode.GDPropObjects6, gdjs.GameCode.GDPropObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects7.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects7[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects7[k] = gdjs.GameCode.GDPropObjects7[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects7.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects7);
gdjs.copyArray(gdjs.GameCode.GDItemObjects6, gdjs.GameCode.GDItemObjects7);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setXOffset(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setYOffset(16);
}
}{for(var i = 0, len = gdjs.GameCode.GDHungerObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects7[i].SetValue(gdjs.GameCode.GDHungerObjects7[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameCode.GDPropObjects6, gdjs.GameCode.GDPropObjects7);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects7.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects7[i].getAnimationFrame() == 3 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects7[k] = gdjs.GameCode.GDPropObjects7[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects7.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects7);
gdjs.copyArray(gdjs.GameCode.GDItemObjects6, gdjs.GameCode.GDItemObjects7);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setXOffset(16);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setYOffset(16);
}
}{for(var i = 0, len = gdjs.GameCode.GDHungerObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects7[i].SetValue(gdjs.GameCode.GDHungerObjects7[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (5), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects5Objects = Hashtable.newFrom({"Item": gdjs.GameCode.GDItemObjects5});
gdjs.GameCode.eventsList36 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.random(10) < 2);
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDItemObjects6 */
{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setXOffset(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setYOffset(16);
}
}}

}


};gdjs.GameCode.eventsList37 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.random(10) < 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDItemObjects6, gdjs.GameCode.GDItemObjects7);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setXOffset(48);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setYOffset(16);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.random(10) < 1);
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDItemObjects6 */
{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setXOffset(32);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setYOffset(16);
}
}}

}


};gdjs.GameCode.eventsList38 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(gdjs.GameCode.GDPropObjects5, gdjs.GameCode.GDPropObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects6.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects6[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects6[k] = gdjs.GameCode.GDPropObjects6[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects6.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDItemObjects5, gdjs.GameCode.GDItemObjects6);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setXOffset(gdjs.randomInRange(0, 3) * 16);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setYOffset(gdjs.randomInRange(0, 1) * 16);
}
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDPropObjects5, gdjs.GameCode.GDPropObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects6.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects6[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects6[k] = gdjs.GameCode.GDPropObjects6[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects6.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects6);
gdjs.copyArray(gdjs.GameCode.GDItemObjects5, gdjs.GameCode.GDItemObjects6);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setXOffset(32);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setYOffset(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDHungerObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects6[i].SetValue(gdjs.GameCode.GDHungerObjects6[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList36(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameCode.GDPropObjects5, gdjs.GameCode.GDPropObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects6.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects6[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects6[k] = gdjs.GameCode.GDPropObjects6[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects6.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects6);
gdjs.copyArray(gdjs.GameCode.GDItemObjects5, gdjs.GameCode.GDItemObjects6);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setXOffset(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setYOffset(16);
}
}{for(var i = 0, len = gdjs.GameCode.GDHungerObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects6[i].SetValue(gdjs.GameCode.GDHungerObjects6[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList37(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameCode.GDPropObjects5, gdjs.GameCode.GDPropObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects6.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects6[i].getAnimationFrame() == 3 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects6[k] = gdjs.GameCode.GDPropObjects6[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects6.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects6);
gdjs.copyArray(gdjs.GameCode.GDItemObjects5, gdjs.GameCode.GDItemObjects6);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setXOffset(16);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setYOffset(16);
}
}{for(var i = 0, len = gdjs.GameCode.GDHungerObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects6[i].SetValue(gdjs.GameCode.GDHungerObjects6[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (5), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.GameCode.eventsList39 = function(runtimeScene, asyncObjectsList) {

{


const repeatCount6 = gdjs.randomInRange(1, 2);
for (let repeatIndex6 = 0;repeatIndex6 < repeatCount6;++repeatIndex6) {
gdjs.copyArray(gdjs.GameCode.GDPropObjects4, gdjs.GameCode.GDPropObjects6);

gdjs.GameCode.GDItemObjects6.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects6Objects, (( gdjs.GameCode.GDPropObjects6.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects6[0].getPointX("")), (( gdjs.GameCode.GDPropObjects6.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects6[0].getPointY("")) - 32, "");
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].returnVariable(gdjs.GameCode.GDItemObjects6[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomFloatInRange(0.4, 1.5));
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].returnVariable(gdjs.GameCode.GDItemObjects6[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomFloatInRange(-(0.7), 0.7));
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].returnVariable(gdjs.GameCode.GDItemObjects6[i].getVariables().get("Y")).setNumber((( gdjs.GameCode.GDPropObjects6.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects6[0].getPointY("")) + gdjs.randomInRange(-(32), 0));
}
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameCode.GDPropObjects6.length !== 0 ? gdjs.GameCode.GDPropObjects6[0] : null), (gdjs.GameCode.GDItemObjects6.length !== 0 ? gdjs.GameCode.GDItemObjects6[0] : null));
}{for(var i = 0, len = gdjs.GameCode.GDPropObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDPropObjects6[i].setOpacity(0);
}
}
{ //Subevents: 
gdjs.GameCode.eventsList35(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


{


const repeatCount5 = gdjs.randomInRange(1, 2);
for (let repeatIndex5 = 0;repeatIndex5 < repeatCount5;++repeatIndex5) {
gdjs.copyArray(gdjs.GameCode.GDPropObjects4, gdjs.GameCode.GDPropObjects5);

gdjs.GameCode.GDItemObjects5.length = 0;


let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects5Objects, (( gdjs.GameCode.GDPropObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects5[0].getPointX("")), (( gdjs.GameCode.GDPropObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects5[0].getPointY("")) - 32, "");
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects5[i].returnVariable(gdjs.GameCode.GDItemObjects5[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomFloatInRange(0.4, 1.5));
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects5[i].returnVariable(gdjs.GameCode.GDItemObjects5[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomFloatInRange(-(0.7), 0.7));
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects5[i].returnVariable(gdjs.GameCode.GDItemObjects5[i].getVariables().get("Y")).setNumber((( gdjs.GameCode.GDPropObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects5[0].getPointY("")) + gdjs.randomInRange(-(32), 0));
}
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameCode.GDPropObjects5.length !== 0 ? gdjs.GameCode.GDPropObjects5[0] : null), (gdjs.GameCode.GDItemObjects5.length !== 0 ? gdjs.GameCode.GDItemObjects5[0] : null));
}{for(var i = 0, len = gdjs.GameCode.GDPropObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDPropObjects5[i].setOpacity(0);
}
}
{ //Subevents: 
gdjs.GameCode.eventsList38(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


};gdjs.GameCode.eventsList40 = function(runtimeScene, asyncObjectsList) {

{

gdjs.copyArray(asyncObjectsList.getObjects("Prop"), gdjs.GameCode.GDPropObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects4[i].getOpacity() < 75 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects4[k] = gdjs.GameCode.GDPropObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects4 */
/* Reuse gdjs.GameCode.GDPropObjects4 */
gdjs.copyArray(asyncObjectsList.getObjects("Hits"), gdjs.GameCode.GDHitsObjects4);

{for(var i = 0, len = gdjs.GameCode.GDPropObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDPropObjects4[i].setOpacity(0);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Poof", false, 25, gdjs.randomFloatInRange(0.9, 1.1));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHitsObjects4Objects, ((( gdjs.GameCode.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects4[0].getPointX("")) + (( gdjs.GameCode.GDPropObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects4[0].getPointX(""))) / 2, ((( gdjs.GameCode.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects4[0].getPointY("")) + (( gdjs.GameCode.GDPropObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects4[0].getPointY(""))) / 2, "");
}{for(var i = 0, len = gdjs.GameCode.GDHitsObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDHitsObjects4[i].setAngle(270);
}
}
{ //Subevents
gdjs.GameCode.eventsList39(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16194940 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.GameCode.GDPlayerObjects4);

{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects4[i].activateBehavior("TopDownMovement", true);
}
}
{ //Subevents
gdjs.GameCode.eventsList40(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList41 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Hits as it will be provided by the parent asyncObjectsList. */
for (const obj of gdjs.GameCode.GDPlayerObjects3) asyncObjectsList.addObject("Player", obj);
/* Don't save Prop as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.GameCode.asyncCallback16194940(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.asyncCallback16194308 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].clearForces();
}
}
{ //Subevents
gdjs.GameCode.eventsList41(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList42 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameCode.GDHitsObjects2) asyncObjectsList.addObject("Hits", obj);
for (const obj of gdjs.GameCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
for (const obj of gdjs.GameCode.GDPropObjects2) asyncObjectsList.addObject("Prop", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.GameCode.asyncCallback16194308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList43 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Prop"), gdjs.GameCode.GDPropObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects2[i].getOpacity() >= 75 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects2[k] = gdjs.GameCode.GDPropObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPropObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPropObjects2[i].getOpacity() != 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPropObjects2[k] = gdjs.GameCode.GDPropObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPropObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16192716);
}
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Energy"), gdjs.GameCode.GDEnergyObjects2);
/* Reuse gdjs.GameCode.GDPlayerObjects2 */
/* Reuse gdjs.GameCode.GDPropObjects2 */
gdjs.GameCode.GDHitsObjects2.length = 0;

{for(var i = 0, len = gdjs.GameCode.GDPropObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPropObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.3, 1, 1, 7, 0.02, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDEnergyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnergyObjects2[i].SetValue(gdjs.GameCode.GDEnergyObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (15), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDPropObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPropObjects2[i].setOpacity(gdjs.GameCode.GDPropObjects2[i].getOpacity() - ((4 - (gdjs.GameCode.GDPropObjects2[i].getAnimationFrame())) * 45));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHitsObjects2Objects, ((( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointX("")) + (( gdjs.GameCode.GDPropObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects2[0].getPointX(""))) / 2, ((( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointY("")) + (( gdjs.GameCode.GDPropObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPropObjects2[0].getPointY(""))) / 2, "");
}{for(var i = 0, len = gdjs.GameCode.GDHitsObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHitsObjects2[i].setAngle(270);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Hits", false, 25, gdjs.randomFloatInRange(0.9, 1.1));
}{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].addForceTowardObject((gdjs.GameCode.GDPropObjects2.length !== 0 ? gdjs.GameCode.GDPropObjects2[0] : null), -(90), 1);
}
}
{ //Subevents
gdjs.GameCode.eventsList42(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects4Objects = Hashtable.newFrom({"Item": gdjs.GameCode.GDItemObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects4});
gdjs.GameCode.asyncCallback16221172 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Assets\\Sfx\\burpmale_sfxb.mp3", false, 25, gdjs.randomFloatInRange(0.9, 1.1));
}}
gdjs.GameCode.eventsList44 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.GameCode.asyncCallback16221172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList45 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDItemObjects5, gdjs.GameCode.GDItemObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects6.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects6[i].getXOffset() == 16 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects6[k] = gdjs.GameCode.GDItemObjects6[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects6.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Energy"), gdjs.GameCode.GDEnergyObjects6);
{for(var i = 0, len = gdjs.GameCode.GDEnergyObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDEnergyObjects6[i].SetValue(gdjs.GameCode.GDEnergyObjects6[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (15), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDItemObjects5, gdjs.GameCode.GDItemObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects6.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects6[i].getXOffset() == 32 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects6[k] = gdjs.GameCode.GDItemObjects6[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects6.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDThirstObjects5, gdjs.GameCode.GDThirstObjects6);

{for(var i = 0, len = gdjs.GameCode.GDThirstObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDThirstObjects6[i].SetValue(gdjs.GameCode.GDThirstObjects6[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (10), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDItemObjects5, gdjs.GameCode.GDItemObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects6.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects6[i].getXOffset() == 48 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects6[k] = gdjs.GameCode.GDItemObjects6[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects6.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDHungerObjects5, gdjs.GameCode.GDHungerObjects6);

gdjs.copyArray(gdjs.GameCode.GDThirstObjects5, gdjs.GameCode.GDThirstObjects6);

{for(var i = 0, len = gdjs.GameCode.GDHungerObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects6[i].SetValue(gdjs.GameCode.GDHungerObjects6[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (15), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDThirstObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDThirstObjects6[i].SetValue(gdjs.GameCode.GDThirstObjects6[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16220020);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList44(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList46 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects5 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects5[i].setString(gdjs.GameCode.GDDebugObjects5[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0))));
}
}}

}


};gdjs.GameCode.eventsList47 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects5 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects5[i].setString(gdjs.GameCode.GDDebugObjects5[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1))));
}
}}

}


};gdjs.GameCode.eventsList48 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects5 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects5[i].setString(gdjs.GameCode.GDDebugObjects5[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2))));
}
}}

}


};gdjs.GameCode.eventsList49 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects4 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects4[i].setString(gdjs.GameCode.GDDebugObjects4[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3))));
}
}}

}


};gdjs.GameCode.eventsList50 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDDebugObjects4, gdjs.GameCode.GDDebugObjects5);

{for(var i = 0, len = gdjs.GameCode.GDDebugObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects5[i].setString(gdjs.GameCode.GDDebugObjects5[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(0)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList46(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDDebugObjects4, gdjs.GameCode.GDDebugObjects5);

{for(var i = 0, len = gdjs.GameCode.GDDebugObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects5[i].setString(gdjs.GameCode.GDDebugObjects5[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(1)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList47(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDDebugObjects4, gdjs.GameCode.GDDebugObjects5);

{for(var i = 0, len = gdjs.GameCode.GDDebugObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects5[i].setString(gdjs.GameCode.GDDebugObjects5[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(2)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList48(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDDebugObjects4 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects4[i].setString(gdjs.GameCode.GDDebugObjects4[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(3)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList49(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList51 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDItemObjects4, gdjs.GameCode.GDItemObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects5.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects5[i].getXOffset() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects5[k] = gdjs.GameCode.GDItemObjects5[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects5.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(0).add(1);
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDItemObjects4, gdjs.GameCode.GDItemObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects5.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects5[i].getXOffset() == 16 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects5[k] = gdjs.GameCode.GDItemObjects5[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects5.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(1).add(1);
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDItemObjects4, gdjs.GameCode.GDItemObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects5.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects5[i].getXOffset() == 32 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects5[k] = gdjs.GameCode.GDItemObjects5[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects5.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(2).add(1);
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDItemObjects4, gdjs.GameCode.GDItemObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects5.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects5[i].getXOffset() == 48 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects5[k] = gdjs.GameCode.GDItemObjects5[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects5.length = k;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(3).add(1);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.GameCode.GDDebugObjects4);
/* Reuse gdjs.GameCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects4[i].setString("POS " + gdjs.evtTools.common.toString(gdjs.evtTools.common.mod(Math.round((( gdjs.GameCode.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects4[0].getPointX("")) / 16), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)))) + " " + gdjs.evtTools.common.toString(gdjs.evtTools.common.mod(Math.round((( gdjs.GameCode.GDPlayerObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects4[0].getPointY("")) / 16), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList50(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList52 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDItemObjects4, gdjs.GameCode.GDItemObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects5.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects5[i].getYOffset() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects5[k] = gdjs.GameCode.GDItemObjects5[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects5.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects5);
gdjs.copyArray(runtimeScene.getObjects("Thirst"), gdjs.GameCode.GDThirstObjects5);
{for(var i = 0, len = gdjs.GameCode.GDHungerObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDHungerObjects5[i].SetValue(gdjs.GameCode.GDHungerObjects5[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (7), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDThirstObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDThirstObjects5[i].SetValue(gdjs.GameCode.GDThirstObjects5[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (7), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList45(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.GameCode.GDItemObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects4[i].getYOffset() == 16 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects4[k] = gdjs.GameCode.GDItemObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList51(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList53 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDItemObjects4 */
/* Reuse gdjs.GameCode.GDPlayerObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects4Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects4Objects, 12, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects4[i].getVariableNumber(gdjs.GameCode.GDItemObjects4[i].getVariables().get("Y")) == -(999) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects4[k] = gdjs.GameCode.GDItemObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects4[i].getVariableNumber(gdjs.GameCode.GDItemObjects4[i].getVariables().get("F")) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects4[k] = gdjs.GameCode.GDItemObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDItemObjects4 */
{for(var i = 0, len = gdjs.GameCode.GDItemObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects4[i].returnVariable(gdjs.GameCode.GDItemObjects4[i].getVariables().getFromIndex(0)).setNumber(3);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects4[i].returnVariable(gdjs.GameCode.GDItemObjects4[i].getVariables().get("Y")).setNumber((gdjs.GameCode.GDItemObjects4[i].getY()) + 16);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects4[i].returnVariable(gdjs.GameCode.GDItemObjects4[i].getVariables().get("F")).setNumber(15);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects4[i].clearForces();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Item", false, 25, gdjs.randomFloatInRange(0.9, 1.1));
}
{ //Subevents
gdjs.GameCode.eventsList52(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList54 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDItemObjects3, gdjs.GameCode.GDItemObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects4.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDItemObjects4[i].getY() < (gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDItemObjects4[i].getVariables().get("Y")))) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects4[k] = gdjs.GameCode.GDItemObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDItemObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects4);
{for(var i = 0, len = gdjs.GameCode.GDItemObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects4[i].returnVariable(gdjs.GameCode.GDItemObjects4[i].getVariables().get("Y")).setNumber(-(999));
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects4[i].addForceTowardObject((gdjs.GameCode.GDPlayerObjects4.length !== 0 ? gdjs.GameCode.GDPlayerObjects4[0] : null), 8, 1);
}
}
{ //Subevents
gdjs.GameCode.eventsList53(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList55 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDItemObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects1[i].getOpacity() < 5 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects1[k] = gdjs.GameCode.GDItemObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDItemObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDItemObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameCode.eventsList56 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects2[i].isCurrentAnimationName("Dash") ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects2[k] = gdjs.GameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList43(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item"), gdjs.GameCode.GDItemObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDItemObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDItemObjects2[i].getY() < (gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDItemObjects2[i].getVariables().get("Y"))) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDItemObjects2[k] = gdjs.GameCode.GDItemObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDItemObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDItemObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDItemObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects2[i].setPosition(gdjs.GameCode.GDItemObjects2[i].getX() +((gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDItemObjects2[i].getVariables().getFromIndex(1)))),gdjs.GameCode.GDItemObjects2[i].getY() -((gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDItemObjects2[i].getVariables().getFromIndex(0)))));
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects2[i].returnVariable(gdjs.GameCode.GDItemObjects2[i].getVariables().getFromIndex(0)).sub(0.2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Item"), gdjs.GameCode.GDItemObjects2);

for (gdjs.GameCode.forEachIndex3 = 0;gdjs.GameCode.forEachIndex3 < gdjs.GameCode.GDItemObjects2.length;++gdjs.GameCode.forEachIndex3) {
gdjs.GameCode.GDItemObjects3.length = 0;


gdjs.GameCode.forEachTemporary3 = gdjs.GameCode.GDItemObjects2[gdjs.GameCode.forEachIndex3];
gdjs.GameCode.GDItemObjects3.push(gdjs.GameCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {

{ //Subevents: 
gdjs.GameCode.eventsList54(runtimeScene);} //Subevents end.
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Item"), gdjs.GameCode.GDItemObjects1);
{for(var i = 0, len = gdjs.GameCode.GDItemObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects1[i].setOpacity(gdjs.GameCode.GDItemObjects1[i].getOpacity() - ((gdjs.RuntimeObject.getVariableNumber(gdjs.GameCode.GDItemObjects1[i].getVariables().get("F")))));
}
}
{ //Subevents
gdjs.GameCode.eventsList55(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList57 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0))));
}
}}

}


};gdjs.GameCode.eventsList58 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1))));
}
}}

}


};gdjs.GameCode.eventsList59 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2))));
}
}}

}


};gdjs.GameCode.eventsList60 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects2[i].setString(gdjs.GameCode.GDDebugObjects2[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3))));
}
}}

}


};gdjs.GameCode.eventsList61 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDDebugObjects2, gdjs.GameCode.GDDebugObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(0)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList57(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDDebugObjects2, gdjs.GameCode.GDDebugObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(1)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList58(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDDebugObjects2, gdjs.GameCode.GDDebugObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(2)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList59(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDDebugObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects2[i].setString(gdjs.GameCode.GDDebugObjects2[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(3)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList60(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList62 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.GameCode.GDDebugObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects2[i].setString("POS " + gdjs.evtTools.common.toString(gdjs.evtTools.common.mod(Math.round((( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointX("")) / 16), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)))) + " " + gdjs.evtTools.common.toString(gdjs.evtTools.common.mod(Math.round((( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointY("")) / 16), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList61(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList63 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0))));
}
}}

}


};gdjs.GameCode.eventsList64 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1))));
}
}}

}


};gdjs.GameCode.eventsList65 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2))));
}
}}

}


};gdjs.GameCode.eventsList66 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3)) != 0;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDDebugObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects2[i].setString(gdjs.GameCode.GDDebugObjects2[i].getString() + ("/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3))));
}
}}

}


};gdjs.GameCode.eventsList67 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDDebugObjects2, gdjs.GameCode.GDDebugObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(0)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList63(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDDebugObjects2, gdjs.GameCode.GDDebugObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(1)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList64(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDDebugObjects2, gdjs.GameCode.GDDebugObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDebugObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects3[i].setString(gdjs.GameCode.GDDebugObjects3[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(2)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList65(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDDebugObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects2[i].setString(gdjs.GameCode.GDDebugObjects2[i].getString() + (gdjs.evtTools.string.newLine() + "   - " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Inventory").getChild(3)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList66(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16249532 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide();
}
}}
gdjs.GameCode.eventsList68 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameCode.GDDialogueObjects2) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.GameCode.asyncCallback16249532(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList69 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].setString("Im Hungry....");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList68(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16250724 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide();
}
}}
gdjs.GameCode.eventsList70 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameCode.GDDialogueObjects2) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.GameCode.asyncCallback16250724(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList71 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].setString("Im Thirsty....");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList70(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16254076 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects4);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].hide();
}
}}
gdjs.GameCode.eventsList72 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects3) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.GameCode.asyncCallback16254076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList73 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDDialogueObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].setString("Make sure I have \nENOUGH Items to survive\nthe Night.....");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList72(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16252908 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide();
}
}
{ //Subevents
gdjs.GameCode.eventsList73(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList74 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.GameCode.GDDialogueObjects2) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.GameCode.asyncCallback16252908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList75 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].setString("I Should Head BACK...");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList74(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList76 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraZoom(runtimeScene, "", 0), 6, 0.2), "", 0);
}{gdjs.evtTools.camera.clampCamera(runtimeScene, 0, 0, 1280, 1280, "", 0);
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].setCenterPositionInScene((( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointX("")),(( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointY("")) - 24);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Trans"), gdjs.GameCode.GDTransObjects2);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "UI", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, 640 / 1.5 / 2, "UI", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, 1080 / 1.5 / 2, "UI", 0);
}{for(var i = 0, len = gdjs.GameCode.GDTransObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTransObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Flash", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList62(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Fog"), gdjs.GameCode.GDFogObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sundial"), gdjs.GameCode.GDSundialObjects2);
gdjs.copyArray(runtimeScene.getObjects("TileTemp"), gdjs.GameCode.GDTileTempObjects2);
{for(var i = 0, len = gdjs.GameCode.GDTileTempObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTileTempObjects2[i].setXOffset(gdjs.GameCode.GDTileTempObjects2[i].getXOffset() + (0.1));
}
}{for(var i = 0, len = gdjs.GameCode.GDTileTempObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTileTempObjects2[i].setYOffset(gdjs.GameCode.GDTileTempObjects2[i].getYOffset() + (0.02));
}
}{for(var i = 0, len = gdjs.GameCode.GDSundialObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSundialObjects2[i].setOpacity(200);
}
}{for(var i = 0, len = gdjs.GameCode.GDFogObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDFogObjects2[i].setOpacity(125);
}
}{for(var i = 0, len = gdjs.GameCode.GDSundialObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSundialObjects2[i].setAngle(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) * 90 - 90);
}
}{for(var i = 0, len = gdjs.GameCode.GDFogObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDFogObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("Biome")) == 3;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fog"), gdjs.GameCode.GDFogObjects2);
{for(var i = 0, len = gdjs.GameCode.GDFogObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDFogObjects2[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) * 6 > Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) * 6));
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.GameCode.GDDebugObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDebugObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDebugObjects2[i].setString("POS " + gdjs.evtTools.common.toString(gdjs.evtTools.common.mod(Math.round((( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointX("")) / 16), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)))) + " " + gdjs.evtTools.common.toString(gdjs.evtTools.common.mod(Math.round((( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getPointY("")) / 16), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(3)))));
}
}
{ //Subevents
gdjs.GameCode.eventsList67(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDHungerObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDHungerObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) < 20 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDHungerObjects2[k] = gdjs.GameCode.GDHungerObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDHungerObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16248268);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList69(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Thirst"), gdjs.GameCode.GDThirstObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDThirstObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDThirstObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) < 20 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDThirstObjects2[k] = gdjs.GameCode.GDThirstObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDThirstObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16249996);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList71(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) > 1.5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16251596);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList75(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Energy"), gdjs.GameCode.GDEnergyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Fog"), gdjs.GameCode.GDFogObjects2);
{for(var i = 0, len = gdjs.GameCode.GDEnergyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnergyObjects2[i].SetValue(gdjs.GameCode.GDEnergyObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (2), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDFogObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDFogObjects2[i].rotate(2, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.GameCode.GDJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("RollButton"), gdjs.GameCode.GDRollButtonObjects1);
{for(var i = 0, len = gdjs.GameCode.GDJoystickObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDJoystickObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDRollButtonObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDRollButtonObjects1[i].hide();
}
}}

}


};gdjs.GameCode.eventsList77 = function(runtimeScene) {

};gdjs.GameCode.eventsList78 = function(runtimeScene) {

{


const repeatCount3 = 40 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME"));
for (let repeatIndex3 = 0;repeatIndex3 < repeatCount3;++repeatIndex3) {

let isConditionTrue_0 = false;
if (true)
{
{runtimeScene.getScene().getVariables().get("TIME").add(3 / (120 * 60));
}}
}

}


};gdjs.GameCode.eventsList79 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0)) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1)) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2)) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3)) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3)) == 0;
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day").add(1);
}{gdjs.evtTools.storage.writeStringInJSONFile("Player", "Data", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Main", "Check", 1);
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Transition");
}}

}


};gdjs.GameCode.asyncCallback16263836 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtsExt__Noise__SetSeed.func(runtimeScene, gdjs.randomInRange(0, 99999), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.storage.writeStringInJSONFile("Player", "Data", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Main", "Check", 1);
}
{ //Subevents
gdjs.GameCode.eventsList79(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList80 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.GameCode.asyncCallback16263836(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList81 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0)) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1)) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2)) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3)) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(0)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(1)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(2)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("RequiredInvent").getChild(3)) == 0;
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day").add(1);
}{gdjs.evtTools.storage.writeStringInJSONFile("Player", "Data", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Main", "Check", 1);
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Transition");
}}

}


};gdjs.GameCode.asyncCallback16269924 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtsExt__Noise__SetSeed.func(runtimeScene, gdjs.randomInRange(0, 99999), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.storage.writeStringInJSONFile("Player", "Data", gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().getFromIndex(0)));
}{gdjs.evtTools.storage.writeNumberInJSONFile("Main", "Check", 1);
}
{ //Subevents
gdjs.GameCode.eventsList81(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList82 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.GameCode.asyncCallback16269924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.asyncCallback16269100 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Trans"), gdjs.GameCode.GDTransObjects2);
{for(var i = 0, len = gdjs.GameCode.GDTransObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTransObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Vertical", "Both", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList82(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList83 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameCode.asyncCallback16269100(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList84 = function(runtimeScene) {

{

gdjs.GameCode.GDForwardObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameCode.GDForwardObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Forward"), gdjs.GameCode.GDForwardObjects3);
for (var i = 0, k = 0, l = gdjs.GameCode.GDForwardObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDForwardObjects3[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDForwardObjects3[k] = gdjs.GameCode.GDForwardObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDForwardObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDForwardObjects3.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDForwardObjects2_1final.indexOf(gdjs.GameCode.GDForwardObjects3[j]) === -1 )
            gdjs.GameCode.GDForwardObjects2_1final.push(gdjs.GameCode.GDForwardObjects3[j]);
    }
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "c");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
gdjs.copyArray(gdjs.GameCode.GDForwardObjects2_1final, gdjs.GameCode.GDForwardObjects2);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList78(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Clock"), gdjs.GameCode.GDClockObjects2);
gdjs.copyArray(runtimeScene.getObjects("Day"), gdjs.GameCode.GDDayObjects2);
{runtimeScene.getScene().getVariables().get("TIME").add(3 / (120 * 60));
}{for(var i = 0, len = gdjs.GameCode.GDDayObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDayObjects2[i].setString("DAY " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) + " " + gdjs.evtTools.string.newLine());
}
}{for(var i = 0, len = gdjs.GameCode.GDDayObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDayObjects2[i].setString(gdjs.GameCode.GDDayObjects2[i].getString() + (gdjs.evtTools.common.toString(1 + gdjs.evtTools.common.mod(6 + Math.round(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) * 6), 12))));
}
}{for(var i = 0, len = gdjs.GameCode.GDClockObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDClockObjects2[i].setAngle(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) * (360 / 3));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) < 1;
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setLayerAmbientLightColor(runtimeScene, "Lighting", gdjs.evtsExt__ColorConversion__RgbMean.func(runtimeScene, "42;47;78", "249;230;207", gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")), 1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) < 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) > 1;
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setLayerAmbientLightColor(runtimeScene, "Lighting", gdjs.evtsExt__ColorConversion__RgbMean.func(runtimeScene, "249;230;207", "198;69;36", gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")), 1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) < 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) > 2;
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setLayerAmbientLightColor(runtimeScene, "Lighting", gdjs.evtsExt__ColorConversion__RgbMean.func(runtimeScene, "198;69;36", "42;47;78", gdjs.evtTools.common.mod(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")), 1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) < 0.8;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Day"), gdjs.GameCode.GDDayObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDayObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDayObjects2[i].setString(gdjs.GameCode.GDDayObjects2[i].getString() + ("am" + gdjs.evtTools.string.newLine()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) < 0.8);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) < 2.8;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Day"), gdjs.GameCode.GDDayObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDayObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDayObjects2[i].setString(gdjs.GameCode.GDDayObjects2[i].getString() + ("pm" + gdjs.evtTools.string.newLine()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) < 2.8);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Day"), gdjs.GameCode.GDDayObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDayObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDayObjects2[i].setString(gdjs.GameCode.GDDayObjects2[i].getString() + ("am" + gdjs.evtTools.string.newLine()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("TIME")) > 2.81;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16263196);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Trans"), gdjs.GameCode.GDTransObjects2);
{for(var i = 0, len = gdjs.GameCode.GDTransObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTransObjects2[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Vertical", "Both", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.GameCode.eventsList80(runtimeScene);} //End of subevents
}

}


{

gdjs.GameCode.GDHungerObjects1.length = 0;

gdjs.GameCode.GDThirstObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameCode.GDHungerObjects1_1final.length = 0;
gdjs.GameCode.GDThirstObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Thirst"), gdjs.GameCode.GDThirstObjects2);
for (var i = 0, k = 0, l = gdjs.GameCode.GDThirstObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDThirstObjects2[i].IsEmpty((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDThirstObjects2[k] = gdjs.GameCode.GDThirstObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDThirstObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDThirstObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDThirstObjects1_1final.indexOf(gdjs.GameCode.GDThirstObjects2[j]) === -1 )
            gdjs.GameCode.GDThirstObjects1_1final.push(gdjs.GameCode.GDThirstObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Hunger"), gdjs.GameCode.GDHungerObjects2);
for (var i = 0, k = 0, l = gdjs.GameCode.GDHungerObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDHungerObjects2[i].IsEmpty((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDHungerObjects2[k] = gdjs.GameCode.GDHungerObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDHungerObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDHungerObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDHungerObjects1_1final.indexOf(gdjs.GameCode.GDHungerObjects2[j]) === -1 )
            gdjs.GameCode.GDHungerObjects1_1final.push(gdjs.GameCode.GDHungerObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameCode.GDHungerObjects1_1final, gdjs.GameCode.GDHungerObjects1);
gdjs.copyArray(gdjs.GameCode.GDThirstObjects1_1final, gdjs.GameCode.GDThirstObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16269028);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList83(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList85 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects7);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects7[i].hide();
}
}}

}


};gdjs.GameCode.asyncCallback16280764 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList85(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList86 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects6) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(6), (runtimeScene) => (gdjs.GameCode.asyncCallback16280764(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList87 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects6);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects6[i].setString("I should find stuff\nto stay alive");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects6[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects6[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList86(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16279692 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList87(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList88 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects5) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.GameCode.asyncCallback16279692(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList89 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects5);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].setString("Stupid plane crashed\non the stupid island.");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList88(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16278676 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList89(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList90 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects4) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.GameCode.asyncCallback16278676(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList91 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects4);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].setString("What a night.");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList90(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16277652 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList91(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList92 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects3) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.GameCode.asyncCallback16277652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList93 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].setString("Ughhhhhhh");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList92(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16276524 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList93(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList94 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.GameCode.asyncCallback16276524(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList95 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects7);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects7[i].hide();
}
}}

}


};gdjs.GameCode.asyncCallback16285772 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList95(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList96 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects6) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(6), (runtimeScene) => (gdjs.GameCode.asyncCallback16285772(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList97 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects6);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects6[i].setString("My Head Hurts..\nSo sticky..\nHard to move..");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects6[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects6[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList96(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16284020 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList97(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList98 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects5) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.GameCode.asyncCallback16284020(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList99 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects5);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].setString("WAIT WHERE AM I???\nI THOUGHT WE'RE...");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList98(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16283724 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList99(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList100 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects4) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.GameCode.asyncCallback16283724(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList101 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects4);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].setString("Mud??!! How Did\nThis Place-");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList100(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16282644 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList101(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList102 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects3) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.GameCode.asyncCallback16282644(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList103 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].setString("Wuhhh- WHAT");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList102(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16281564 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList103(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList104 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameCode.asyncCallback16281564(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList105 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects7);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects7[i].hide();
}
}}

}


};gdjs.GameCode.asyncCallback16290028 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList105(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList106 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects6) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.GameCode.asyncCallback16290028(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList107 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects6);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects6[i].setString("I can't see very well..\nStupid fog..");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects6[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects6[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList106(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16289692 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList107(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList108 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects5) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.GameCode.asyncCallback16289692(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList109 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects5);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].setString("How are people gonna\nFIND ME????");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList108(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16288668 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList109(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList110 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects4) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.GameCode.asyncCallback16288668(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList111 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects4);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].setString("So this happens \neveryday..");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList110(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16287604 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList111(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList112 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects3) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.GameCode.asyncCallback16287604(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList113 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].setString(".......");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList112(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16286572 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList113(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList114 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameCode.asyncCallback16286572(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.asyncCallback16294444 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects6);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects6[i].hide();
}
}}
gdjs.GameCode.eventsList115 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects5) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.GameCode.asyncCallback16294444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList116 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDDialogueObjects5 */
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].setString("I can't go out far\ntho, my stuff can only\nstay in that circle..");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList115(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16293660 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects5);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects5[i].hide();
}
}
{ //Subevents
gdjs.GameCode.eventsList116(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList117 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects4) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.GameCode.asyncCallback16293660(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList118 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects4);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].setString("One of these islands\nhas to be close to\nislands with people..");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList117(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16292604 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList118(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList119 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects3) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.GameCode.asyncCallback16292604(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList120 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].setString("Maybe....");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList119(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16291556 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList120(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList121 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameCode.asyncCallback16291556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.asyncCallback16296516 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects4);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].hide();
}
}}
gdjs.GameCode.eventsList122 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects3) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.GameCode.asyncCallback16296516(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList123 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].setString("Wow 10 days....\nI mean i'm fine..\nDon't lose hope yet...");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList122(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16295420 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList123(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList124 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameCode.asyncCallback16295420(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.asyncCallback16297828 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects4);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].hide();
}
}}
gdjs.GameCode.eventsList125 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects3) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.GameCode.asyncCallback16297828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList126 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].setString("Almost a month...\nThey might have given up\nInstead of me :C");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList125(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16296796 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList126(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList127 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameCode.asyncCallback16296796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.asyncCallback16300084 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects4);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects4[i].hide();
}
}}
gdjs.GameCode.eventsList128 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects3) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.GameCode.asyncCallback16300084(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList129 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].setString("I could turn this into\na 100 day series...");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList128(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16298724 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList129(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList130 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameCode.asyncCallback16298724(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.asyncCallback16301884 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects3);

{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects3[i].hide();
}
}}
gdjs.GameCode.eventsList131 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.GameCode.GDDialogueObjects2) asyncObjectsList.addObject("Dialogue", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.GameCode.asyncCallback16301884(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList132 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].setString("No way....\nBruh");
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].getBehavior("Text_AutoTyping").StartAtBeginning((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.GameCode.eventsList131(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.GameCode.asyncCallback16300796 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.GameCode.eventsList132(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.GameCode.eventsList133 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameCode.asyncCallback16300796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.eventsList134 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].getBehavior("Text_AutoTyping").SkipToEnd((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].setString("");
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.GameCode.GDDialogueObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.GameCode.GDDialogueObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDDialogueObjects2[i].setZOrder((( gdjs.GameCode.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects2[0].getZOrder()) + 3);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) == 1;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16276292);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList94(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) == 2;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16281340);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList104(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) == 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16286348);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList114(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) == 5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16290956);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList121(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) == 10;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16295348);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList124(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) == 25;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16296900);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList127(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) == 50;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16298932);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList130(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Day")) == 100;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16300724);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList133(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects3Objects = Hashtable.newFrom({"Tile": gdjs.GameCode.GDTileObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHitsObjects3Objects = Hashtable.newFrom({"Hits": gdjs.GameCode.GDHitsObjects3});
gdjs.GameCode.eventsList135 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Energy"), gdjs.GameCode.GDEnergyObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);
gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.GameCode.GDTileObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects3[i].isCollidingWithPoint((( gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects3[0].getPointY(""))) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects3[k] = gdjs.GameCode.GDTileObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects3[i].getAnimationFrame() <= 1 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects3[k] = gdjs.GameCode.GDTileObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects3Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects3Objects, 48, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDEnergyObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDEnergyObjects3[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDEnergyObjects3[k] = gdjs.GameCode.GDEnergyObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDEnergyObjects3.length = k;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDEnergyObjects3 */
/* Reuse gdjs.GameCode.GDPlayerObjects3 */
/* Reuse gdjs.GameCode.GDTileObjects3 */
gdjs.GameCode.GDHitsObjects3.length = 0;

{for(var i = 0, len = gdjs.GameCode.GDTileObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDTileObjects3[i].setAnimationFrame(8);
}
}{for(var i = 0, len = gdjs.GameCode.GDEnergyObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDEnergyObjects3[i].SetValue(gdjs.GameCode.GDEnergyObjects3[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (20), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHitsObjects3Objects, (( gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects3[0].getPointX("")), (( gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameCode.GDHitsObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDHitsObjects3[i].setAngle(270);
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects4Objects = Hashtable.newFrom({"Tile": gdjs.GameCode.GDTileObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects6Objects = Hashtable.newFrom({"Item": gdjs.GameCode.GDItemObjects6});
gdjs.GameCode.eventsList136 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.random(10) < 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDItemObjects6, gdjs.GameCode.GDItemObjects7);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setXOffset(48);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setYOffset(0);
}
}}

}


};gdjs.GameCode.eventsList137 = function(runtimeScene) {

{


const repeatCount6 = gdjs.randomInRange(1, 2);
for (let repeatIndex6 = 0;repeatIndex6 < repeatCount6;++repeatIndex6) {
gdjs.copyArray(gdjs.GameCode.GDTileObjects4, gdjs.GameCode.GDTileObjects6);

gdjs.GameCode.GDItemObjects6.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.random(10) < 2);
}
if (isConditionTrue_0)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects6Objects, (( gdjs.GameCode.GDTileObjects6.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects6[0].getCenterXInScene()), (( gdjs.GameCode.GDTileObjects6.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects6[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].returnVariable(gdjs.GameCode.GDItemObjects6[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomFloatInRange(0.4, 1.5));
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].returnVariable(gdjs.GameCode.GDItemObjects6[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomFloatInRange(-(0.7), 0.7));
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].returnVariable(gdjs.GameCode.GDItemObjects6[i].getVariables().get("Y")).setNumber((( gdjs.GameCode.GDTileObjects6.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects6[0].getCenterYInScene()) + 32);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setXOffset(32);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setYOffset(16);
}
}
{ //Subevents: 
gdjs.GameCode.eventsList136(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameCode.eventsList138 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.GameCode.GDTileObjects3);

for (gdjs.GameCode.forEachIndex4 = 0;gdjs.GameCode.forEachIndex4 < gdjs.GameCode.GDTileObjects3.length;++gdjs.GameCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects4);
gdjs.GameCode.GDTileObjects4.length = 0;


gdjs.GameCode.forEachTemporary4 = gdjs.GameCode.GDTileObjects3[gdjs.GameCode.forEachIndex4];
gdjs.GameCode.GDTileObjects4.push(gdjs.GameCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects4Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects4Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects4[i].getAnimationFrame() < 2 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects4[k] = gdjs.GameCode.GDTileObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.GameCode.eventsList137(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects4Objects = Hashtable.newFrom({"Tile": gdjs.GameCode.GDTileObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects4Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects6Objects = Hashtable.newFrom({"Item": gdjs.GameCode.GDItemObjects6});
gdjs.GameCode.eventsList139 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.random(10) < 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDItemObjects6, gdjs.GameCode.GDItemObjects7);

{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setXOffset(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects7.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects7[i].setYOffset(0);
}
}}

}


};gdjs.GameCode.eventsList140 = function(runtimeScene) {

{


const repeatCount6 = gdjs.randomInRange(1, 2);
for (let repeatIndex6 = 0;repeatIndex6 < repeatCount6;++repeatIndex6) {
gdjs.copyArray(gdjs.GameCode.GDTileObjects4, gdjs.GameCode.GDTileObjects6);

gdjs.GameCode.GDItemObjects6.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.random(10) < 3);
}
if (isConditionTrue_0)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDItemObjects6Objects, (( gdjs.GameCode.GDTileObjects6.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects6[0].getCenterXInScene()), (( gdjs.GameCode.GDTileObjects6.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects6[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].returnVariable(gdjs.GameCode.GDItemObjects6[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomFloatInRange(0.4, 1.5));
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].returnVariable(gdjs.GameCode.GDItemObjects6[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomFloatInRange(-(0.7), 0.7));
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].returnVariable(gdjs.GameCode.GDItemObjects6[i].getVariables().get("Y")).setNumber((( gdjs.GameCode.GDTileObjects6.length === 0 ) ? 0 :gdjs.GameCode.GDTileObjects6[0].getCenterYInScene()) + 32);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setXOffset(48);
}
}{for(var i = 0, len = gdjs.GameCode.GDItemObjects6.length ;i < len;++i) {
    gdjs.GameCode.GDItemObjects6[i].setYOffset(16);
}
}
{ //Subevents: 
gdjs.GameCode.eventsList139(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameCode.eventsList141 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.GameCode.GDTileObjects3);

for (gdjs.GameCode.forEachIndex4 = 0;gdjs.GameCode.forEachIndex4 < gdjs.GameCode.GDTileObjects3.length;++gdjs.GameCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects4);
gdjs.GameCode.GDTileObjects4.length = 0;


gdjs.GameCode.forEachTemporary4 = gdjs.GameCode.GDTileObjects3[gdjs.GameCode.forEachIndex4];
gdjs.GameCode.GDTileObjects4.push(gdjs.GameCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDTileObjects4Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects4Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDTileObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDTileObjects4[i].getAnimationFrame() > 3 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDTileObjects4[k] = gdjs.GameCode.GDTileObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDTileObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents: 
gdjs.GameCode.eventsList140(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects3Objects = Hashtable.newFrom({"Prop": gdjs.GameCode.GDPropObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects3});
gdjs.GameCode.eventsList142 = function(runtimeScene) {

};gdjs.GameCode.eventsList143 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Prop"), gdjs.GameCode.GDPropObjects2);

for (gdjs.GameCode.forEachIndex3 = 0;gdjs.GameCode.forEachIndex3 < gdjs.GameCode.GDPropObjects2.length;++gdjs.GameCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);
gdjs.GameCode.GDPropObjects3.length = 0;


gdjs.GameCode.forEachTemporary3 = gdjs.GameCode.GDPropObjects2[gdjs.GameCode.forEachIndex3];
gdjs.GameCode.GDPropObjects3.push(gdjs.GameCode.forEachTemporary3);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPropObjects3Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects3Objects, 64, false);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.GameCode.GDPropObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPropObjects3[i].setOpacity(80);
}
}}
}

}


};gdjs.GameCode.eventsList144 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDActionButtonObjects2, gdjs.GameCode.GDActionButtonObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDActionButtonObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDActionButtonObjects3[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDActionButtonObjects3[k] = gdjs.GameCode.GDActionButtonObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDActionButtonObjects3.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Action");
}{gdjs.evtTools.sound.playSound(runtimeScene, "splash.mp3", false, 25, 1);
}
{ //Subevents
gdjs.GameCode.eventsList138(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.GameCode.GDActionButtonObjects2, gdjs.GameCode.GDActionButtonObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDActionButtonObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDActionButtonObjects3[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDActionButtonObjects3[k] = gdjs.GameCode.GDActionButtonObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDActionButtonObjects3.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Action");
}{gdjs.evtTools.sound.playSound(runtimeScene, "swing.mp3", false, 25, 1);
}
{ //Subevents
gdjs.GameCode.eventsList141(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.GameCode.GDActionButtonObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDActionButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDActionButtonObjects2[i].getAnimationFrame() == 3 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDActionButtonObjects2[k] = gdjs.GameCode.GDActionButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDActionButtonObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Action");
}
{ //Subevents
gdjs.GameCode.eventsList143(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList145 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDActionButtonObjects2, gdjs.GameCode.GDActionButtonObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDActionButtonObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDActionButtonObjects3[i].getAnimationFrame() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDActionButtonObjects3[k] = gdjs.GameCode.GDActionButtonObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDActionButtonObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDActionButtonObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDActionButtonObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDActionButtonObjects3[i].setOpacity(175);
}
}{for(var i = 0, len = gdjs.GameCode.GDActionButtonObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDActionButtonObjects3[i].setOpacity(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "Action") / 7 * 255);
}
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDActionButtonObjects2, gdjs.GameCode.GDActionButtonObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDActionButtonObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDActionButtonObjects3[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDActionButtonObjects3[k] = gdjs.GameCode.GDActionButtonObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDActionButtonObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDActionButtonObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDActionButtonObjects3[i].getAnimationFrame() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDActionButtonObjects3[k] = gdjs.GameCode.GDActionButtonObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDActionButtonObjects3.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList135(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.GameCode.GDActionButtonObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDActionButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDActionButtonObjects2[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDActionButtonObjects2[k] = gdjs.GameCode.GDActionButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDActionButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Action") >= 7;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDActionButtonObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDActionButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDActionButtonObjects2[i].setOpacity(175);
}
}
{ //Subevents
gdjs.GameCode.eventsList144(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList146 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num1");
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Tools").getChild("Type").setNumber(0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num2");
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Tools").getChild("Type").setNumber(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num3");
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Tools").getChild("Type").setNumber(2);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Num4");
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Tools").getChild("Type").setNumber(3);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Tools").getChild("Type").setNumber(-(1));
}}

}


};gdjs.GameCode.eventsList147 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Action");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Tools").getChild("Type")) == -(1);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ActionButton"), gdjs.GameCode.GDActionButtonObjects2);
{for(var i = 0, len = gdjs.GameCode.GDActionButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDActionButtonObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ActionButton"), gdjs.GameCode.GDActionButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("RollButton"), gdjs.GameCode.GDRollButtonObjects2);
{for(var i = 0, len = gdjs.GameCode.GDActionButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDActionButtonObjects2[i].setOpacity(255);
}
}{for(var i = 0, len = gdjs.GameCode.GDRollButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDRollButtonObjects2[i].setOpacity(255);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RollButton"), gdjs.GameCode.GDRollButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDRollButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDRollButtonObjects2[i].getBehavior("ButtonFSM").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDRollButtonObjects2[k] = gdjs.GameCode.GDRollButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDRollButtonObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDRollButtonObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDRollButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDRollButtonObjects2[i].setOpacity(175);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Tools").getChild("Type")) > -(1);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ActionButton"), gdjs.GameCode.GDActionButtonObjects2);
{for(var i = 0, len = gdjs.GameCode.GDActionButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDActionButtonObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameCode.GDActionButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDActionButtonObjects2[i].setAnimationFrame(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Tools").getChild("Type")));
}
}
{ //Subevents
gdjs.GameCode.eventsList145(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList146(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList148 = function(runtimeScene) {

{


gdjs.GameCode.eventsList4(runtimeScene);
}


{


gdjs.GameCode.eventsList11(runtimeScene);
}


{


gdjs.GameCode.eventsList32(runtimeScene);
}


{


gdjs.GameCode.eventsList56(runtimeScene);
}


{


gdjs.GameCode.eventsList76(runtimeScene);
}


{


gdjs.GameCode.eventsList84(runtimeScene);
}


{


gdjs.GameCode.eventsList134(runtimeScene);
}


{


gdjs.GameCode.eventsList147(runtimeScene);
}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDTransObjects1.length = 0;
gdjs.GameCode.GDTransObjects2.length = 0;
gdjs.GameCode.GDTransObjects3.length = 0;
gdjs.GameCode.GDTransObjects4.length = 0;
gdjs.GameCode.GDTransObjects5.length = 0;
gdjs.GameCode.GDTransObjects6.length = 0;
gdjs.GameCode.GDTransObjects7.length = 0;
gdjs.GameCode.GDTransObjects8.length = 0;
gdjs.GameCode.GDTransObjects9.length = 0;
gdjs.GameCode.GDTileTempObjects1.length = 0;
gdjs.GameCode.GDTileTempObjects2.length = 0;
gdjs.GameCode.GDTileTempObjects3.length = 0;
gdjs.GameCode.GDTileTempObjects4.length = 0;
gdjs.GameCode.GDTileTempObjects5.length = 0;
gdjs.GameCode.GDTileTempObjects6.length = 0;
gdjs.GameCode.GDTileTempObjects7.length = 0;
gdjs.GameCode.GDTileTempObjects8.length = 0;
gdjs.GameCode.GDTileTempObjects9.length = 0;
gdjs.GameCode.GDPlayerObjects1.length = 0;
gdjs.GameCode.GDPlayerObjects2.length = 0;
gdjs.GameCode.GDPlayerObjects3.length = 0;
gdjs.GameCode.GDPlayerObjects4.length = 0;
gdjs.GameCode.GDPlayerObjects5.length = 0;
gdjs.GameCode.GDPlayerObjects6.length = 0;
gdjs.GameCode.GDPlayerObjects7.length = 0;
gdjs.GameCode.GDPlayerObjects8.length = 0;
gdjs.GameCode.GDPlayerObjects9.length = 0;
gdjs.GameCode.GDPropObjects1.length = 0;
gdjs.GameCode.GDPropObjects2.length = 0;
gdjs.GameCode.GDPropObjects3.length = 0;
gdjs.GameCode.GDPropObjects4.length = 0;
gdjs.GameCode.GDPropObjects5.length = 0;
gdjs.GameCode.GDPropObjects6.length = 0;
gdjs.GameCode.GDPropObjects7.length = 0;
gdjs.GameCode.GDPropObjects8.length = 0;
gdjs.GameCode.GDPropObjects9.length = 0;
gdjs.GameCode.GDShadowPropObjects1.length = 0;
gdjs.GameCode.GDShadowPropObjects2.length = 0;
gdjs.GameCode.GDShadowPropObjects3.length = 0;
gdjs.GameCode.GDShadowPropObjects4.length = 0;
gdjs.GameCode.GDShadowPropObjects5.length = 0;
gdjs.GameCode.GDShadowPropObjects6.length = 0;
gdjs.GameCode.GDShadowPropObjects7.length = 0;
gdjs.GameCode.GDShadowPropObjects8.length = 0;
gdjs.GameCode.GDShadowPropObjects9.length = 0;
gdjs.GameCode.GDItemObjects1.length = 0;
gdjs.GameCode.GDItemObjects2.length = 0;
gdjs.GameCode.GDItemObjects3.length = 0;
gdjs.GameCode.GDItemObjects4.length = 0;
gdjs.GameCode.GDItemObjects5.length = 0;
gdjs.GameCode.GDItemObjects6.length = 0;
gdjs.GameCode.GDItemObjects7.length = 0;
gdjs.GameCode.GDItemObjects8.length = 0;
gdjs.GameCode.GDItemObjects9.length = 0;
gdjs.GameCode.GDTileObjects1.length = 0;
gdjs.GameCode.GDTileObjects2.length = 0;
gdjs.GameCode.GDTileObjects3.length = 0;
gdjs.GameCode.GDTileObjects4.length = 0;
gdjs.GameCode.GDTileObjects5.length = 0;
gdjs.GameCode.GDTileObjects6.length = 0;
gdjs.GameCode.GDTileObjects7.length = 0;
gdjs.GameCode.GDTileObjects8.length = 0;
gdjs.GameCode.GDTileObjects9.length = 0;
gdjs.GameCode.GDDustObjects1.length = 0;
gdjs.GameCode.GDDustObjects2.length = 0;
gdjs.GameCode.GDDustObjects3.length = 0;
gdjs.GameCode.GDDustObjects4.length = 0;
gdjs.GameCode.GDDustObjects5.length = 0;
gdjs.GameCode.GDDustObjects6.length = 0;
gdjs.GameCode.GDDustObjects7.length = 0;
gdjs.GameCode.GDDustObjects8.length = 0;
gdjs.GameCode.GDDustObjects9.length = 0;
gdjs.GameCode.GDHitsObjects1.length = 0;
gdjs.GameCode.GDHitsObjects2.length = 0;
gdjs.GameCode.GDHitsObjects3.length = 0;
gdjs.GameCode.GDHitsObjects4.length = 0;
gdjs.GameCode.GDHitsObjects5.length = 0;
gdjs.GameCode.GDHitsObjects6.length = 0;
gdjs.GameCode.GDHitsObjects7.length = 0;
gdjs.GameCode.GDHitsObjects8.length = 0;
gdjs.GameCode.GDHitsObjects9.length = 0;
gdjs.GameCode.GDSplashObjects1.length = 0;
gdjs.GameCode.GDSplashObjects2.length = 0;
gdjs.GameCode.GDSplashObjects3.length = 0;
gdjs.GameCode.GDSplashObjects4.length = 0;
gdjs.GameCode.GDSplashObjects5.length = 0;
gdjs.GameCode.GDSplashObjects6.length = 0;
gdjs.GameCode.GDSplashObjects7.length = 0;
gdjs.GameCode.GDSplashObjects8.length = 0;
gdjs.GameCode.GDSplashObjects9.length = 0;
gdjs.GameCode.GDEnergyObjects1.length = 0;
gdjs.GameCode.GDEnergyObjects2.length = 0;
gdjs.GameCode.GDEnergyObjects3.length = 0;
gdjs.GameCode.GDEnergyObjects4.length = 0;
gdjs.GameCode.GDEnergyObjects5.length = 0;
gdjs.GameCode.GDEnergyObjects6.length = 0;
gdjs.GameCode.GDEnergyObjects7.length = 0;
gdjs.GameCode.GDEnergyObjects8.length = 0;
gdjs.GameCode.GDEnergyObjects9.length = 0;
gdjs.GameCode.GDThirstObjects1.length = 0;
gdjs.GameCode.GDThirstObjects2.length = 0;
gdjs.GameCode.GDThirstObjects3.length = 0;
gdjs.GameCode.GDThirstObjects4.length = 0;
gdjs.GameCode.GDThirstObjects5.length = 0;
gdjs.GameCode.GDThirstObjects6.length = 0;
gdjs.GameCode.GDThirstObjects7.length = 0;
gdjs.GameCode.GDThirstObjects8.length = 0;
gdjs.GameCode.GDThirstObjects9.length = 0;
gdjs.GameCode.GDHungerObjects1.length = 0;
gdjs.GameCode.GDHungerObjects2.length = 0;
gdjs.GameCode.GDHungerObjects3.length = 0;
gdjs.GameCode.GDHungerObjects4.length = 0;
gdjs.GameCode.GDHungerObjects5.length = 0;
gdjs.GameCode.GDHungerObjects6.length = 0;
gdjs.GameCode.GDHungerObjects7.length = 0;
gdjs.GameCode.GDHungerObjects8.length = 0;
gdjs.GameCode.GDHungerObjects9.length = 0;
gdjs.GameCode.GDDebugObjects1.length = 0;
gdjs.GameCode.GDDebugObjects2.length = 0;
gdjs.GameCode.GDDebugObjects3.length = 0;
gdjs.GameCode.GDDebugObjects4.length = 0;
gdjs.GameCode.GDDebugObjects5.length = 0;
gdjs.GameCode.GDDebugObjects6.length = 0;
gdjs.GameCode.GDDebugObjects7.length = 0;
gdjs.GameCode.GDDebugObjects8.length = 0;
gdjs.GameCode.GDDebugObjects9.length = 0;
gdjs.GameCode.GDDialogueObjects1.length = 0;
gdjs.GameCode.GDDialogueObjects2.length = 0;
gdjs.GameCode.GDDialogueObjects3.length = 0;
gdjs.GameCode.GDDialogueObjects4.length = 0;
gdjs.GameCode.GDDialogueObjects5.length = 0;
gdjs.GameCode.GDDialogueObjects6.length = 0;
gdjs.GameCode.GDDialogueObjects7.length = 0;
gdjs.GameCode.GDDialogueObjects8.length = 0;
gdjs.GameCode.GDDialogueObjects9.length = 0;
gdjs.GameCode.GDDayObjects1.length = 0;
gdjs.GameCode.GDDayObjects2.length = 0;
gdjs.GameCode.GDDayObjects3.length = 0;
gdjs.GameCode.GDDayObjects4.length = 0;
gdjs.GameCode.GDDayObjects5.length = 0;
gdjs.GameCode.GDDayObjects6.length = 0;
gdjs.GameCode.GDDayObjects7.length = 0;
gdjs.GameCode.GDDayObjects8.length = 0;
gdjs.GameCode.GDDayObjects9.length = 0;
gdjs.GameCode.GDJoystickObjects1.length = 0;
gdjs.GameCode.GDJoystickObjects2.length = 0;
gdjs.GameCode.GDJoystickObjects3.length = 0;
gdjs.GameCode.GDJoystickObjects4.length = 0;
gdjs.GameCode.GDJoystickObjects5.length = 0;
gdjs.GameCode.GDJoystickObjects6.length = 0;
gdjs.GameCode.GDJoystickObjects7.length = 0;
gdjs.GameCode.GDJoystickObjects8.length = 0;
gdjs.GameCode.GDJoystickObjects9.length = 0;
gdjs.GameCode.GDRollButtonObjects1.length = 0;
gdjs.GameCode.GDRollButtonObjects2.length = 0;
gdjs.GameCode.GDRollButtonObjects3.length = 0;
gdjs.GameCode.GDRollButtonObjects4.length = 0;
gdjs.GameCode.GDRollButtonObjects5.length = 0;
gdjs.GameCode.GDRollButtonObjects6.length = 0;
gdjs.GameCode.GDRollButtonObjects7.length = 0;
gdjs.GameCode.GDRollButtonObjects8.length = 0;
gdjs.GameCode.GDRollButtonObjects9.length = 0;
gdjs.GameCode.GDActionButtonObjects1.length = 0;
gdjs.GameCode.GDActionButtonObjects2.length = 0;
gdjs.GameCode.GDActionButtonObjects3.length = 0;
gdjs.GameCode.GDActionButtonObjects4.length = 0;
gdjs.GameCode.GDActionButtonObjects5.length = 0;
gdjs.GameCode.GDActionButtonObjects6.length = 0;
gdjs.GameCode.GDActionButtonObjects7.length = 0;
gdjs.GameCode.GDActionButtonObjects8.length = 0;
gdjs.GameCode.GDActionButtonObjects9.length = 0;
gdjs.GameCode.GDTestTerrainObjects1.length = 0;
gdjs.GameCode.GDTestTerrainObjects2.length = 0;
gdjs.GameCode.GDTestTerrainObjects3.length = 0;
gdjs.GameCode.GDTestTerrainObjects4.length = 0;
gdjs.GameCode.GDTestTerrainObjects5.length = 0;
gdjs.GameCode.GDTestTerrainObjects6.length = 0;
gdjs.GameCode.GDTestTerrainObjects7.length = 0;
gdjs.GameCode.GDTestTerrainObjects8.length = 0;
gdjs.GameCode.GDTestTerrainObjects9.length = 0;
gdjs.GameCode.GDTilesObjects1.length = 0;
gdjs.GameCode.GDTilesObjects2.length = 0;
gdjs.GameCode.GDTilesObjects3.length = 0;
gdjs.GameCode.GDTilesObjects4.length = 0;
gdjs.GameCode.GDTilesObjects5.length = 0;
gdjs.GameCode.GDTilesObjects6.length = 0;
gdjs.GameCode.GDTilesObjects7.length = 0;
gdjs.GameCode.GDTilesObjects8.length = 0;
gdjs.GameCode.GDTilesObjects9.length = 0;
gdjs.GameCode.GDUITextObjects1.length = 0;
gdjs.GameCode.GDUITextObjects2.length = 0;
gdjs.GameCode.GDUITextObjects3.length = 0;
gdjs.GameCode.GDUITextObjects4.length = 0;
gdjs.GameCode.GDUITextObjects5.length = 0;
gdjs.GameCode.GDUITextObjects6.length = 0;
gdjs.GameCode.GDUITextObjects7.length = 0;
gdjs.GameCode.GDUITextObjects8.length = 0;
gdjs.GameCode.GDUITextObjects9.length = 0;
gdjs.GameCode.GDUIText2Objects1.length = 0;
gdjs.GameCode.GDUIText2Objects2.length = 0;
gdjs.GameCode.GDUIText2Objects3.length = 0;
gdjs.GameCode.GDUIText2Objects4.length = 0;
gdjs.GameCode.GDUIText2Objects5.length = 0;
gdjs.GameCode.GDUIText2Objects6.length = 0;
gdjs.GameCode.GDUIText2Objects7.length = 0;
gdjs.GameCode.GDUIText2Objects8.length = 0;
gdjs.GameCode.GDUIText2Objects9.length = 0;
gdjs.GameCode.GDUIText3Objects1.length = 0;
gdjs.GameCode.GDUIText3Objects2.length = 0;
gdjs.GameCode.GDUIText3Objects3.length = 0;
gdjs.GameCode.GDUIText3Objects4.length = 0;
gdjs.GameCode.GDUIText3Objects5.length = 0;
gdjs.GameCode.GDUIText3Objects6.length = 0;
gdjs.GameCode.GDUIText3Objects7.length = 0;
gdjs.GameCode.GDUIText3Objects8.length = 0;
gdjs.GameCode.GDUIText3Objects9.length = 0;
gdjs.GameCode.GDFogObjects1.length = 0;
gdjs.GameCode.GDFogObjects2.length = 0;
gdjs.GameCode.GDFogObjects3.length = 0;
gdjs.GameCode.GDFogObjects4.length = 0;
gdjs.GameCode.GDFogObjects5.length = 0;
gdjs.GameCode.GDFogObjects6.length = 0;
gdjs.GameCode.GDFogObjects7.length = 0;
gdjs.GameCode.GDFogObjects8.length = 0;
gdjs.GameCode.GDFogObjects9.length = 0;
gdjs.GameCode.GDInventIconObjects1.length = 0;
gdjs.GameCode.GDInventIconObjects2.length = 0;
gdjs.GameCode.GDInventIconObjects3.length = 0;
gdjs.GameCode.GDInventIconObjects4.length = 0;
gdjs.GameCode.GDInventIconObjects5.length = 0;
gdjs.GameCode.GDInventIconObjects6.length = 0;
gdjs.GameCode.GDInventIconObjects7.length = 0;
gdjs.GameCode.GDInventIconObjects8.length = 0;
gdjs.GameCode.GDInventIconObjects9.length = 0;
gdjs.GameCode.GDClockObjects1.length = 0;
gdjs.GameCode.GDClockObjects2.length = 0;
gdjs.GameCode.GDClockObjects3.length = 0;
gdjs.GameCode.GDClockObjects4.length = 0;
gdjs.GameCode.GDClockObjects5.length = 0;
gdjs.GameCode.GDClockObjects6.length = 0;
gdjs.GameCode.GDClockObjects7.length = 0;
gdjs.GameCode.GDClockObjects8.length = 0;
gdjs.GameCode.GDClockObjects9.length = 0;
gdjs.GameCode.GDForwardObjects1.length = 0;
gdjs.GameCode.GDForwardObjects2.length = 0;
gdjs.GameCode.GDForwardObjects3.length = 0;
gdjs.GameCode.GDForwardObjects4.length = 0;
gdjs.GameCode.GDForwardObjects5.length = 0;
gdjs.GameCode.GDForwardObjects6.length = 0;
gdjs.GameCode.GDForwardObjects7.length = 0;
gdjs.GameCode.GDForwardObjects8.length = 0;
gdjs.GameCode.GDForwardObjects9.length = 0;
gdjs.GameCode.GDCampObjects1.length = 0;
gdjs.GameCode.GDCampObjects2.length = 0;
gdjs.GameCode.GDCampObjects3.length = 0;
gdjs.GameCode.GDCampObjects4.length = 0;
gdjs.GameCode.GDCampObjects5.length = 0;
gdjs.GameCode.GDCampObjects6.length = 0;
gdjs.GameCode.GDCampObjects7.length = 0;
gdjs.GameCode.GDCampObjects8.length = 0;
gdjs.GameCode.GDCampObjects9.length = 0;
gdjs.GameCode.GDSundialObjects1.length = 0;
gdjs.GameCode.GDSundialObjects2.length = 0;
gdjs.GameCode.GDSundialObjects3.length = 0;
gdjs.GameCode.GDSundialObjects4.length = 0;
gdjs.GameCode.GDSundialObjects5.length = 0;
gdjs.GameCode.GDSundialObjects6.length = 0;
gdjs.GameCode.GDSundialObjects7.length = 0;
gdjs.GameCode.GDSundialObjects8.length = 0;
gdjs.GameCode.GDSundialObjects9.length = 0;

gdjs.GameCode.eventsList148(runtimeScene);

return;

}

gdjs['GameCode'] = gdjs.GameCode;
